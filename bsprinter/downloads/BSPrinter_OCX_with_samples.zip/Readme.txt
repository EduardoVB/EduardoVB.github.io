If you are upgrading from a previous version, unregister the old ocx first. 
Also delete the *.oca file.
After that, register the new ocx with admin rigths.
Open the VB6 IDE with admin rights at least the first time after you register the ocx, and add the ':) BSprinter' component to a project.
