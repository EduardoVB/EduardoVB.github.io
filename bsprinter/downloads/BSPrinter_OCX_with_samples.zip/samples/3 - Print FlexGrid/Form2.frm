VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form Form2 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "FlexGrid sample hiding columns"
   ClientHeight    =   8040
   ClientLeft      =   3876
   ClientTop       =   2616
   ClientWidth     =   9012
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   8040
   ScaleWidth      =   9012
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MSHFlexGrid1 
      Height          =   5532
      Left            =   120
      TabIndex        =   3
      Top             =   480
      Width           =   8724
      _ExtentX        =   15388
      _ExtentY        =   9758
      _Version        =   393216
      ScrollTrack     =   -1  'True
      ScrollBars      =   2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _NumberOfBands  =   1
      _Band(0).Cols   =   2
   End
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   6888
      TabIndex        =   2
      Top             =   7380
      Width           =   1572
   End
   Begin VB.CommandButton cmdPrint 
      Caption         =   "Print"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   504
      TabIndex        =   0
      Top             =   7380
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   2328
      Top             =   7320
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label3 
      Caption         =   "Years 1980 and 2000 are not printed."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   228
      Left            =   216
      TabIndex        =   7
      Top             =   6864
      Width           =   7068
   End
   Begin VB.Label Label2 
      Caption         =   "It is done by using the ColsToHide optional parameter of the PrintGrid method."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   228
      Left            =   216
      TabIndex        =   6
      Top             =   6528
      Width           =   7068
   End
   Begin VB.Label lblTitle2 
      Caption         =   "(in thousands)"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   3552
      TabIndex        =   5
      Top             =   168
      Width           =   2172
   End
   Begin VB.Label lblTitle 
      AutoSize        =   -1  'True
      Caption         =   "World population by country"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   10.2
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   252
      Left            =   312
      TabIndex        =   4
      Top             =   120
      Width           =   2952
   End
   Begin VB.Label Label1 
      Caption         =   "This is almost the same sample, but shows how to print the grid without some columns."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   228
      Left            =   216
      TabIndex        =   1
      Top             =   6192
      Width           =   8460
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdPrint_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

Private Sub cmdClose_Click()
    Unload Me
End Sub

Private Sub Form_Load()
    Dim cn As New ADODB.Connection
    Dim rs As New ADODB.Recordset
    Dim c As Long
    
    ' Load data on the grid
    cn.Provider = "Microsoft.Jet.OLEDB.4.0"
    cn.Open App.Path & "\PopBD.mdb", "", ""
    rs.Open "Select * From World_Population", cn, adOpenStatic
    
    MSHFlexGrid1.FixedCols = 0
    Set MSHFlexGrid1.DataSource = rs
    
    For c = 0 To MSHFlexGrid1.Cols - 1
        If c = 2 Then
            MSHFlexGrid1.ColWidth(c) = 2900
        ElseIf c = 0 Then
            MSHFlexGrid1.ColWidth(c) = 0
        Else
            MSHFlexGrid1.ColWidth(c) = 1100
        End If
    Next
    MSHFlexGrid1.TextMatrix(0, 1) = "Country code"
    MSHFlexGrid1.TextMatrix(0, 2) = "Country Name"
    MSHFlexGrid1.TextMatrix(0, 3) = "1960"
    MSHFlexGrid1.TextMatrix(0, 4) = "1980"
    MSHFlexGrid1.TextMatrix(0, 5) = "2000"
    MSHFlexGrid1.TextMatrix(0, 6) = "2020"
    MSHFlexGrid1.Row = 0
    For c = 0 To MSHFlexGrid1.Cols - 1
        MSHFlexGrid1.Col = c
        MSHFlexGrid1.CellFontBold = True
        MSHFlexGrid1.CellAlignment = flexAlignCenterCenter
    Next c
    MSHFlexGrid1.ColAlignment(1) = flexAlignLeftCenter
    
End Sub

Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim ColsToHide() As Boolean
    
    ' Title
    Printer.FontSize = 18
    Printer.FontBold = True
    Printer.Print lblTitle.Caption
    Printer.FontSize = 12
    Printer.Print lblTitle2.Caption
    Printer.Print
    Printer.FontBold = False
    
    ' Print the grid
    ReDim ColsToHide(MSHFlexGrid1.Cols - 1)
    ColsToHide(3) = True ' year 1980
    ColsToHide(4) = True ' year 2000
    PrintPreview1.PrintGrid MSHFlexGrid1, , , , ColsToHide ' (this is the only code line needed for printing the grid)
    
    Printer.Print
    Printer.Print "Data published by United Nations"
    Printer.FontSize = 10
    Printer.Print "https://population.un.org/wpp/Download/Standard/Population/"
End Sub

