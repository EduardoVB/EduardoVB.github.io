VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Allow/disallow user actions"
   ClientHeight    =   7872
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   6588
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   7872
   ScaleWidth      =   6588
   Begin VB.CheckBox chkAUCPNPosition 
      Caption         =   "Position"
      Height          =   324
      Left            =   3840
      TabIndex        =   17
      Top             =   4296
      Width           =   860
   End
   Begin VB.CheckBox chkAUCPNFormat 
      Caption         =   "Format"
      Height          =   324
      Left            =   4848
      TabIndex        =   16
      Top             =   4296
      Width           =   840
   End
   Begin VB.CheckBox chkAUCPNColor 
      Caption         =   "Color"
      Height          =   324
      Left            =   5832
      TabIndex        =   15
      Top             =   4296
      Width           =   700
   End
   Begin VB.CheckBox chkAUCPNFont 
      Caption         =   "Font"
      Height          =   324
      Left            =   3048
      TabIndex        =   14
      Top             =   4296
      Width           =   648
   End
   Begin VB.ComboBox cboToolbarIconsSize 
      Height          =   312
      Left            =   2004
      Style           =   2  'Dropdown List
      TabIndex        =   11
      Top             =   4700
      Width           =   3852
   End
   Begin VB.CheckBox chkAllowUserChangeScale 
      Caption         =   "AllowUserChangeScale"
      Height          =   324
      Left            =   480
      TabIndex        =   7
      Top             =   3912
      Width           =   3132
   End
   Begin VB.CheckBox chkAllowUserChangePrinter 
      Caption         =   "AllowUserChangePrinter"
      Height          =   324
      Left            =   480
      TabIndex        =   6
      Top             =   3528
      Width           =   3132
   End
   Begin VB.CheckBox chkAllowUserChangePaperSize 
      Caption         =   "AllowUserChangePaperSize"
      Height          =   324
      Left            =   480
      TabIndex        =   5
      Top             =   3144
      Width           =   3132
   End
   Begin VB.CheckBox chkAllowUserChangeOrientation 
      Caption         =   "AllowUserChangeOrientation"
      Height          =   324
      Left            =   480
      TabIndex        =   4
      Top             =   2760
      Width           =   3132
   End
   Begin VB.CheckBox chkAllowUserChangeMargins 
      Caption         =   "AllowUserChangeMargins"
      Height          =   324
      Left            =   480
      TabIndex        =   3
      Top             =   2376
      Width           =   3132
   End
   Begin VB.PictureBox Picture1 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   4944
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   372
      ScaleWidth      =   324
      TabIndex        =   8
      Top             =   2664
      Visible         =   0   'False
      Width           =   372
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview window"
      Height          =   612
      Left            =   840
      TabIndex        =   0
      Top             =   336
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3312
      Top             =   336
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label6 
      Caption         =   $"Form1.frx":186F2
      Height          =   1428
      Left            =   288
      TabIndex        =   13
      Top             =   5976
      Width           =   6084
   End
   Begin VB.Label Label5 
      Caption         =   $"Form1.frx":1886C
      Height          =   708
      Left            =   288
      TabIndex        =   12
      Top             =   5232
      Width           =   6084
   End
   Begin VB.Label Label4 
      Caption         =   "ToolbarIconsSize:"
      Height          =   324
      Left            =   480
      TabIndex        =   10
      Top             =   4754
      Width           =   1452
   End
   Begin VB.Label Label3 
      Caption         =   "AllowUserChangePageNumbers:"
      Height          =   324
      Left            =   480
      TabIndex        =   9
      Top             =   4320
      Width           =   3108
   End
   Begin VB.Label Label2 
      Caption         =   "With this sample you can test their effect:"
      Height          =   372
      Left            =   288
      TabIndex        =   2
      Top             =   1900
      Width           =   4140
   End
   Begin VB.Label Label1 
      Caption         =   "The following are control's properties that you can use to enabe or disable user actions, their names are self explanatory."
      Height          =   564
      Left            =   288
      TabIndex        =   1
      Top             =   1320
      Width           =   6084
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cboToolbarIconsSize_Click()
    PrintPreview1.ToolbarIconsSize = cboToolbarIconsSize.ItemData(cboToolbarIconsSize.ListIndex)
End Sub

Private Sub chkAllowUserChangeMargins_Click()
    PrintPreview1.AllowUserChangeMargins = chkAllowUserChangeMargins.Value
End Sub

Private Sub chkAllowUserChangeOrientation_Click()
    PrintPreview1.AllowUserChangeOrientation = CBool(chkAllowUserChangeOrientation.Value)
End Sub

Private Sub chkAllowUserChangePaperSize_Click()
    PrintPreview1.AllowUserChangePaperSize = CBool(chkAllowUserChangePaperSize.Value)
End Sub

Private Sub chkAllowUserChangePrinter_Click()
    PrintPreview1.AllowUserChangePrinter = CBool(chkAllowUserChangePrinter.Value)
End Sub

Private Sub chkAllowUserChangeScale_Click()
    PrintPreview1.AllowUserChangeScale = CBool(chkAllowUserChangeScale.Value)
End Sub

Private Sub chkAUCPNFont_Click()
    If chkAUCPNFont.Value Then
        PrintPreview1.AllowUserChangePageNumbers = PrintPreview1.AllowUserChangePageNumbers Or bsCPAllowChangeFont
    Else
        PrintPreview1.AllowUserChangePageNumbers = PrintPreview1.AllowUserChangePageNumbers And Not bsCPAllowChangeFont
    End If
    chkAUCPNColor.Enabled = PrintPreview1.AllowUserChangePageNumbers And bsCPAllowChangeFont
End Sub

Private Sub chkAUCPNPosition_Click()
    If chkAUCPNPosition.Value Then
        PrintPreview1.AllowUserChangePageNumbers = PrintPreview1.AllowUserChangePageNumbers Or bsCPAllowChangePosition
    Else
        PrintPreview1.AllowUserChangePageNumbers = PrintPreview1.AllowUserChangePageNumbers And Not bsCPAllowChangePosition
    End If
End Sub

Private Sub chkAUCPNFormat_Click()
    If chkAUCPNFormat.Value Then
        PrintPreview1.AllowUserChangePageNumbers = PrintPreview1.AllowUserChangePageNumbers Or bsCPAllowChangeFormat
    Else
        PrintPreview1.AllowUserChangePageNumbers = PrintPreview1.AllowUserChangePageNumbers And Not bsCPAllowChangeFormat
    End If
End Sub

Private Sub chkAUCPNColor_Click()
    If chkAUCPNColor.Value Then
        PrintPreview1.AllowUserChangePageNumbers = PrintPreview1.AllowUserChangePageNumbers Or bsCPAllowChangeColor
    Else
        PrintPreview1.AllowUserChangePageNumbers = PrintPreview1.AllowUserChangePageNumbers And Not bsCPAllowChangeColor
    End If
End Sub

Private Sub Form_Load()
    chkAllowUserChangeMargins.Value = CLng((PrintPreview1.AllowUserChangeMargins <> bsCMNo)) * -1
    chkAllowUserChangeOrientation.Value = CLng(PrintPreview1.AllowUserChangeOrientation) * -1
    chkAllowUserChangePaperSize.Value = CLng(PrintPreview1.AllowUserChangePaperSize) * -1
    chkAllowUserChangePrinter.Value = CLng(PrintPreview1.AllowUserChangePrinter) * -1
    chkAllowUserChangeScale.Value = CLng(PrintPreview1.AllowUserChangeScale) * -1
    chkAUCPNFont.Value = PrintPreview1.AllowUserChangePageNumbers And bsCPAllowChangeFont \ bsCPAllowChangeFont
    chkAUCPNPosition.Value = PrintPreview1.AllowUserChangePageNumbers And bsCPAllowChangePosition \ bsCPAllowChangePosition
    chkAUCPNFormat.Value = PrintPreview1.AllowUserChangePageNumbers And bsCPAllowChangeFormat \ bsCPAllowChangeFormat
    chkAUCPNColor.Value = PrintPreview1.AllowUserChangePageNumbers And bsCPAllowChangeColor \ bsCPAllowChangeColor

    cboToolbarIconsSize.AddItem bsPPTIconsAutoAndUserCanChange & " - bsPPTIconsAutoAndUserCanChange": cboToolbarIconsSize.ItemData(cboToolbarIconsSize.NewIndex) = bsPPTIconsAutoAndUserCanChange
    cboToolbarIconsSize.AddItem bsPPTIconsSmallAndUserCanChange & " - bsPPTIconsSmallAndUserCanChange": cboToolbarIconsSize.ItemData(cboToolbarIconsSize.NewIndex) = bsPPTIconsSmallAndUserCanChange
    cboToolbarIconsSize.AddItem bsPPTIconsMediumAndUserCanChange & " - bsPPTIconsMediumAndUserCanChange": cboToolbarIconsSize.ItemData(cboToolbarIconsSize.NewIndex) = bsPPTIconsMediumAndUserCanChange
    cboToolbarIconsSize.AddItem bsPPTIconsBigAndUserCanChange & " - bsPPTIconsBigAndUserCanChange": cboToolbarIconsSize.ItemData(cboToolbarIconsSize.NewIndex) = bsPPTIconsBigAndUserCanChange
    cboToolbarIconsSize.AddItem bsPPTIconsAuto & " - bsPPTIconsAuto": cboToolbarIconsSize.ItemData(cboToolbarIconsSize.NewIndex) = bsPPTIconsAuto
    cboToolbarIconsSize.AddItem bsPPTIconsSmall & " - bsPPTIconsSmall": cboToolbarIconsSize.ItemData(cboToolbarIconsSize.NewIndex) = bsPPTIconsSmall
    cboToolbarIconsSize.AddItem bsPPTIconsMedium & " - bsPPTIconsMedium": cboToolbarIconsSize.ItemData(cboToolbarIconsSize.NewIndex) = bsPPTIconsMedium
    cboToolbarIconsSize.AddItem bsPPTIconsBig & " - bsPPTIconsBig": cboToolbarIconsSize.ItemData(cboToolbarIconsSize.NewIndex) = bsPPTIconsBig
    
    Dim c As Long
    
    For c = 0 To cboToolbarIconsSize.ListCount - 1
        If cboToolbarIconsSize.ItemData(c) = PrintPreview1.ToolbarIconsSize Then
            cboToolbarIconsSize.ListIndex = c
            Exit For
        End If
    Next c
End Sub

Private Sub Command1_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

' code taken from Sample 2, just to print something
Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim Str As String
    
    ' Text positioning
    
    Printer.FontSize = 18
    Printer.FontBold = True
    
    'The following code centers the title
    Str = "CENTERED TITLE"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.Print Str
    Printer.Print vbCrLf ' line feed to have some space with the next printing
    
    Printer.FontSize = 12
    Printer.FontBold = False
    
    ' Text positioned at left
    Printer.Print "Left positioned";
    
    ' Text positioned at right
    Str = "Right positioned"
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text positioned at bottom left
    Str = "Bottom left"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.Print Str
    
    ' Text positioned at bottom right
    Str = "Bottom right"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text at center of page
    Str = "Page centered"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.CurrentY = (Printer.ScaleHeight - Printer.TextHeight(Str)) / 2
    Printer.Print Str
    
    
    ' Page 2
    ' Image positioning
    Printer.NewPage
    
    ' Left top
    Printer.PaintPicture Picture1.Picture, 0, 0
    
    ' Right top
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), 0

    ' Left Bottom
    Printer.PaintPicture Picture1.Picture, 0, Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Right Bottom
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Centered in page
    Printer.PaintPicture Picture1.Picture, (Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode)) / 2, (Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)) / 2

    
    ' Page 3
    ' Some elements of always the same size, no matter the scale the user sets
    Printer.NewPage
    Printer.Print "Some elements keep their size"
    Printer.Print "(regardless of scale)"

    Printer.FontSize = 24 * 100 / PrintPreview1.ScalePercent
    
    Printer.Print
    Printer.Print
    Printer.Print ; "Scale independent text size"
    
    Printer.FontSize = 12 ' restore the font size to old value of 12
    Printer.Print "Variable size text"
    
    ' Fixed size image
    Dim Proportion As Single
    
    Printer.Print
    Printer.Print
    Printer.Print "Scale independent image size:"
    
    ' Image width of always half page width (the margins are not taken into account) and horizontally centered
    Proportion = Printer.ScaleWidth / 2 / Picture1.Picture.Width
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth / 4, Printer.CurrentY + 500, Picture1.Picture.Width * Proportion, Picture1.Picture.Height * Proportion
    
    ' Page 4
    Printer.NewPage
    ' All page os fixed size, regardless of the sacle the user has set
    ' Notes:
    ' This technique can be used for full pages, because it changes Printer.Zoom, and it can be changed after the pages is created
    ' Printer.Zoom needs to be restored in the next page
    
    Printer.Zoom = 100 / PrintPreview1.ScalePercent * 100
    Printer.Print "All page the same size, no matter scale"
    Printer.PaintPicture Picture1.Picture, 0, 500
    Printer.CurrentY = 2700
    Printer.Print "Boat in the middle of the sea"
    
    ' Page 5
    ' Drawing
    Printer.NewPage
    Printer.Zoom = 100
    
    Str = "Drawing" ' title
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.FontUnderline = True
    Printer.Print Str & vbCrLf
    Printer.FontUnderline = False
    
    ' Circle centered horizontally
    Printer.DrawWidth = 10
    Printer.Circle (Printer.ScaleWidth / 2, 2000), 1500, vbRed
    
    ' Rectangle at left
    Printer.Line (0, 4000)-(3000, 6000), vbBlue, B
    
    ' Filled rectangle at right
    Printer.Line (Printer.ScaleWidth - 3000, 4000)-(Printer.ScaleWidth, 6000), vbGreen, BF
    
    ' Triangle drawn with lines, horizontally centered at bottom
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
End Sub

