VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form Form3 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "FlexGrid sample define two new styles"
   ClientHeight    =   8040
   ClientLeft      =   6888
   ClientTop       =   2232
   ClientWidth     =   9012
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   8040
   ScaleWidth      =   9012
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MSHFlexGrid1 
      Height          =   5032
      Left            =   120
      TabIndex        =   2
      Top             =   480
      Width           =   8724
      _ExtentX        =   15388
      _ExtentY        =   8869
      _Version        =   393216
      ScrollTrack     =   -1  'True
      ScrollBars      =   2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _NumberOfBands  =   1
      _Band(0).Cols   =   2
   End
   Begin VB.CommandButton cmdPrint 
      Caption         =   "Print"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   504
      TabIndex        =   0
      Top             =   7392
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   2328
      Top             =   7320
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label2 
      Caption         =   $"Form3.frx":00A0
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   444
      Left            =   288
      TabIndex        =   6
      Top             =   6552
      Width           =   8700
   End
   Begin VB.Label Label5 
      Caption         =   "You can also remove styles with the Remove method of PrintPreview1.GridReportStyles, even the standard ones."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   444
      Left            =   252
      TabIndex        =   5
      Top             =   5976
      Width           =   8700
   End
   Begin VB.Label lblTitle2 
      Caption         =   "(in thousands)"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   3552
      TabIndex        =   4
      Top             =   168
      Width           =   2172
   End
   Begin VB.Label lblTitle 
      AutoSize        =   -1  'True
      Caption         =   "World population by country"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   10.2
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   252
      Left            =   312
      TabIndex        =   3
      Top             =   120
      Width           =   2952
   End
   Begin VB.Label Label1 
      Caption         =   "It adds two new styles and sets one as default."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   228
      Left            =   240
      TabIndex        =   1
      Top             =   5640
      Width           =   7452
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdPrint_Click()
    Dim RS As GridReportStyle
    
    ' If you already printed a report with a grid withe the syle changed
    ' and the user settings are remembered (RememberUserPreferences property)
    ' then you won't see the default grid style that we've set here (below, in PrintPreview1.PrintGrid...).
    ' you can delete the user preferences by uncommenting the following line:
    'PrintPreview1.DeleteUserPreferences
    ' run once and then comment it again
    
    ' Here we will define a new style,
    ' alternatively you can use the PrintPreview1.GridReportStyles.CreateNew method if you prefer
    Set RS = New GridReportStyle
    ' When a new style object is created, it starts with the default values set to the style 'Basic'
    ' then you can modify any setting
    With RS
        .HeaderBackgroundColor = &HFFE8E8            ' a blue
        .DrawHeaderBorder = False
        .HeaderBorderColor = &HF08080
        .OuterBorderColor = &HF08080
        .DrawColumnsHeadersLines = False
        .ColumnsDataLinesColor = &HF08080
        .LineThickness = 5
        .DrawHeaderSeparatorLine = True
        .HeaderSeparatorLineThickness = 20
        .Name = "Blue Headers"
    End With
    PrintPreview1.GridReportStyles.Add RS
    
    ' Here we will define another new style
    Set RS = New GridReportStyle
    With RS
        .HeaderBackgroundColor = &HE8F0E8            ' a green
        .DrawHeaderBorder = False
        .HeaderBorderColor = &H40B040
        .OuterBorderColor = &H40B040
        .DrawColumnsHeadersLines = False
        .ColumnsDataLinesColor = &H40B040
        .LineThickness = 5
        .DrawHeaderSeparatorLine = True
        .HeaderSeparatorLineThickness = 20
        .Name = "Green Headers"
    End With
    PrintPreview1.GridReportStyles.Add RS
    
    ' show the dialog
    PrintPreview1.ShowPreview
End Sub

Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    ' Title
    Printer.FontSize = 18
    Printer.FontBold = True
    Printer.Print lblTitle.Caption
    Printer.FontSize = 12
    Printer.Print lblTitle2.Caption
    Printer.Print
    Printer.FontBold = False
    
    ' Print the grid setting the "Blue Headers" style as the default
    PrintPreview1.PrintGrid MSHFlexGrid1, "Green Headers"
    
    Printer.Print
    Printer.Print "Data published by United Nations"
    Printer.FontSize = 10
    Printer.Print "https://population.un.org/wpp/Download/Standard/Population/"
End Sub

Private Sub Form_Load()
    Dim cn As New ADODB.Connection
    Dim RS As New ADODB.Recordset
    Dim c As Long
    
    ' Load data on the grid
    cn.Provider = "Microsoft.Jet.OLEDB.4.0"
    cn.Open App.Path & "\PopBD.mdb", "", ""
    RS.Open "Select * From World_Population", cn, adOpenStatic
    
    MSHFlexGrid1.FixedCols = 0
    Set MSHFlexGrid1.DataSource = RS
    
    For c = 0 To MSHFlexGrid1.Cols - 1
        If c = 2 Then
            MSHFlexGrid1.ColWidth(c) = 2900
        ElseIf c = 0 Then
            MSHFlexGrid1.ColWidth(c) = 0
        Else
            MSHFlexGrid1.ColWidth(c) = 1100
        End If
    Next
    MSHFlexGrid1.TextMatrix(0, 1) = "Country code"
    MSHFlexGrid1.TextMatrix(0, 2) = "Country Name"
    MSHFlexGrid1.TextMatrix(0, 3) = "1960"
    MSHFlexGrid1.TextMatrix(0, 4) = "1980"
    MSHFlexGrid1.TextMatrix(0, 5) = "2000"
    MSHFlexGrid1.TextMatrix(0, 6) = "2020"
    MSHFlexGrid1.Row = 0
    For c = 0 To MSHFlexGrid1.Cols - 1
        MSHFlexGrid1.Col = c
        MSHFlexGrid1.CellFontBold = True
        MSHFlexGrid1.CellAlignment = flexAlignCenterCenter
    Next c
    MSHFlexGrid1.ColAlignment(1) = flexAlignLeftCenter
    
End Sub

