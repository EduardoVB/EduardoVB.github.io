VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "FlexGrid sample changing default style"
   ClientHeight    =   7584
   ClientLeft      =   96
   ClientTop       =   1656
   ClientWidth     =   9012
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   7584
   ScaleWidth      =   9012
   Begin VB.CommandButton Command3 
      Caption         =   "Form3: define two new styles"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   540
      Left            =   5808
      TabIndex        =   10
      Top             =   6792
      Width           =   3004
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Form2: define a new style and add it at the PrintGrid method"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   540
      Left            =   2568
      TabIndex        =   9
      Top             =   6792
      Width           =   3004
   End
   Begin VB.CommandButton Command1 
      Height          =   420
      Left            =   7152
      MaskColor       =   &H00FF00FF&
      Picture         =   "Form1.frx":0000
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   5784
      UseMaskColor    =   -1  'True
      Width           =   468
   End
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MSHFlexGrid1 
      Height          =   4932
      Left            =   120
      TabIndex        =   2
      Top             =   480
      Width           =   8724
      _ExtentX        =   15388
      _ExtentY        =   8700
      _Version        =   393216
      ScrollTrack     =   -1  'True
      ScrollBars      =   2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _NumberOfBands  =   1
      _Band(0).Cols   =   2
   End
   Begin VB.CommandButton cmdPrint 
      Caption         =   "Print"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   540
      Left            =   504
      TabIndex        =   0
      Top             =   6768
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   2040
      Top             =   6816
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label4 
      Caption         =   "If you don't want the user to be able to change the style, set the UserCanChangeStyle of the PrintGrid method to False."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   444
      Left            =   240
      TabIndex        =   8
      Top             =   6216
      Width           =   7956
   End
   Begin VB.Label Label3 
      Caption         =   "at the toolbar."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   252
      Left            =   7752
      TabIndex        =   7
      Top             =   5880
      Width           =   1164
   End
   Begin VB.Label Label2 
      Caption         =   "The user later can change the ""style"" in the Format Dialog box by pressing the button"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   228
      Left            =   240
      TabIndex        =   5
      Top             =   5880
      Width           =   7068
   End
   Begin VB.Label lblTitle2 
      Caption         =   "(in thousands)"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   3552
      TabIndex        =   4
      Top             =   168
      Width           =   2172
   End
   Begin VB.Label lblTitle 
      AutoSize        =   -1  'True
      Caption         =   "World population by country"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   10.2
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   252
      Left            =   312
      TabIndex        =   3
      Top             =   120
      Width           =   2952
   End
   Begin VB.Label Label1 
      Caption         =   "It customizes the default style by choosing one of the built-in styles."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   228
      Left            =   264
      TabIndex        =   1
      Top             =   5544
      Width           =   7452
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdPrint_Click()
    ' If you already printed a report with a grid withe the syle changed
    ' and the user settings are remembered (RememberUserPreferences property)
    ' then you won't see the default grid style that we've set here (below, in PrintPreview1.PrintGrid...).
    ' you can delete the user preferences by uncommenting the following line:
    'PrintPreview1.DeleteUserPreferences
    ' run once and then comment it again
    
    ' show the Print Preview dialog
    PrintPreview1.UILanguage = 9
    PrintPreview1.ShowPreview
End Sub

Private Sub Command2_Click()
    Form2.Show
End Sub

Private Sub Command3_Click()
    Form3.Show
End Sub

Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    ' Title
    Printer.FontSize = 18
    Printer.FontBold = True
    Printer.Print lblTitle.Caption
    Printer.FontSize = 12
    Printer.Print lblTitle2.Caption
    Printer.Print
    Printer.FontBold = False
    
    ' momentarily uncomment this block if you want to get all style names and their indexes
'    Dim c As Long
'
'    For c = 1 To PrintPreview1.GridReportStyles.Count
'        Debug.Print c, PrintPreview1.GridReportStyles(c).Name
'    Next
    
    ' Print the grid
    PrintPreview1.PrintGrid MSHFlexGrid1, 29  ' Free Green
    
    Printer.Print
    Printer.Print "Data published by United Nations"
    Printer.FontSize = 10
    Printer.Print "https://population.un.org/wpp/Download/Standard/Population/"
End Sub

Private Sub Form_Load()
    Dim cn As New ADODB.Connection
    Dim RS As New ADODB.Recordset
    Dim c As Long
    
    ' Load data on the grid
    cn.Provider = "Microsoft.Jet.OLEDB.4.0"
    cn.Open App.Path & "\PopBD.mdb", "", ""
    RS.Open "Select * From World_Population", cn, adOpenStatic
    
    MSHFlexGrid1.FixedCols = 0
    Set MSHFlexGrid1.DataSource = RS
    
    For c = 0 To MSHFlexGrid1.Cols - 1
        If c = 2 Then
            MSHFlexGrid1.ColWidth(c) = 2900
        ElseIf c = 0 Then
            MSHFlexGrid1.ColWidth(c) = 0
        Else
            MSHFlexGrid1.ColWidth(c) = 1100
        End If
    Next
    MSHFlexGrid1.TextMatrix(0, 1) = "Country code"
    MSHFlexGrid1.TextMatrix(0, 2) = "Country Name"
    MSHFlexGrid1.TextMatrix(0, 3) = "1960"
    MSHFlexGrid1.TextMatrix(0, 4) = "1980"
    MSHFlexGrid1.TextMatrix(0, 5) = "2000"
    MSHFlexGrid1.TextMatrix(0, 6) = "2020"
    MSHFlexGrid1.Row = 0
    For c = 0 To MSHFlexGrid1.Cols - 1
        MSHFlexGrid1.Col = c
        MSHFlexGrid1.CellFontBold = True
        MSHFlexGrid1.CellAlignment = flexAlignCenterCenter
    Next c
    MSHFlexGrid1.ColAlignment(1) = flexAlignLeftCenter
    
End Sub

