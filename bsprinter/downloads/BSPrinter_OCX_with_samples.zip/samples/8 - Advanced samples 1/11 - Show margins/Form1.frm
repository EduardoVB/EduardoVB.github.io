VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Show margins"
   ClientHeight    =   5820
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   5160
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   5820
   ScaleWidth      =   5160
   Begin VB.CheckBox chkMarginsButtonVisible 
      Caption         =   "MarginsButtonVisible"
      Height          =   324
      Left            =   480
      TabIndex        =   7
      Top             =   1992
      Width           =   3132
   End
   Begin VB.CheckBox chkShowMargins 
      Caption         =   "ShowMargins"
      Height          =   324
      Left            =   480
      TabIndex        =   6
      Top             =   2400
      Width           =   3132
   End
   Begin VB.PictureBox Picture1 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1548
      Left            =   4368
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   1500
      ScaleWidth      =   660
      TabIndex        =   2
      Top             =   1224
      Visible         =   0   'False
      Width           =   708
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview window"
      Height          =   612
      Left            =   984
      TabIndex        =   0
      Top             =   456
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3288
      Top             =   456
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label5 
      Caption         =   "Note: The margins can be changed by dragging the lines."
      Height          =   420
      Left            =   300
      TabIndex        =   8
      Top             =   5112
      Width           =   4620
   End
   Begin VB.Label Label4 
      Caption         =   $"Form1.frx":18652
      Height          =   780
      Left            =   300
      TabIndex        =   5
      Top             =   4296
      Width           =   4620
   End
   Begin VB.Label Label3 
      Caption         =   "ShowMargins sets the initial state. Its default setting is also False."
      Height          =   492
      Left            =   300
      TabIndex        =   4
      Top             =   3744
      Width           =   4620
   End
   Begin VB.Label Label2 
      Caption         =   $"Form1.frx":18707
      Height          =   708
      Left            =   300
      TabIndex        =   3
      Top             =   2928
      Width           =   4620
   End
   Begin VB.Label Label1 
      Caption         =   "There are two properties: ShowMargins and MarginsButtonVisible."
      Height          =   540
      Left            =   300
      TabIndex        =   1
      Top             =   1368
      Width           =   4620
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub chkMarginsButtonVisible_Click()
    PrintPreview1.MarginsButtonVisible = CBool(chkMarginsButtonVisible.Value)
End Sub

Private Sub chkShowMargins_Click()
    PrintPreview1.ShowMargins = CBool(chkShowMargins.Value)
End Sub

Private Sub Command1_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
    chkShowMargins.Value = CLng(PrintPreview1.ShowMargins) * -1 ' update current state
End Sub

Private Sub Form_Load()
    chkMarginsButtonVisible.Value = CLng(PrintPreview1.MarginsButtonVisible) * -1
    chkShowMargins.Value = CLng(PrintPreview1.ShowMargins) * -1
End Sub

' code taken from Sample 2, just to print something
Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim Str As String
    
    ' Text positioning
    
    Printer.FontSize = 18
    Printer.FontBold = True
    
    'The following code centers the title
    Str = "CENTERED TITLE"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.Print Str
    Printer.Print vbCrLf ' line feed to have some space with the next printing
    
    Printer.FontSize = 12
    Printer.FontBold = False
    
    ' Text positioned at left
    Printer.Print "Left positioned";
    
    ' Text positioned at right
    Str = "Right positioned"
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text positioned at bottom left
    Str = "Bottom left"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.Print Str
    
    ' Text positioned at bottom right
    Str = "Bottom right"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text at center of page
    Str = "Page centered"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.CurrentY = (Printer.ScaleHeight - Printer.TextHeight(Str)) / 2
    Printer.Print Str
    
    
    ' Page 2
    ' Image positioning
    Printer.NewPage
    
    ' Left top
    Printer.PaintPicture Picture1.Picture, 0, 0
    
    ' Right top
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), 0

    ' Left Bottom
    Printer.PaintPicture Picture1.Picture, 0, Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Right Bottom
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Centered in page
    Printer.PaintPicture Picture1.Picture, (Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode)) / 2, (Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)) / 2

    
    ' Page 3
    ' Some elements of always the same size, no matter the scale the user sets
    Printer.NewPage
    Printer.Print "Some elements keep their size"
    Printer.Print "(regardless of scale)"

    Printer.FontSize = 24 * 100 / PrintPreview1.ScalePercent
    
    Printer.Print
    Printer.Print
    Printer.Print ; "Scale independent text size"
    
    Printer.FontSize = 12 ' restore the font size to old value of 12
    Printer.Print "Variable size text"
    
    ' Fixed size image
    Dim Proportion As Single
    
    Printer.Print
    Printer.Print
    Printer.Print "Scale independent image size:"
    
    ' Image width of always half page width (the margins are not taken into account) and horizontally centered
    Proportion = Printer.ScaleWidth / 2 / Picture1.Picture.Width
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth / 4, Printer.CurrentY + 500, Picture1.Picture.Width * Proportion, Picture1.Picture.Height * Proportion
    
    ' Page 4
    Printer.NewPage
    ' All page os fixed size, regardless of the sacle the user has set
    ' Notes:
    ' This technique can be used for full pages, because it changes Printer.Zoom, and it can be changed after the pages is created
    ' Printer.Zoom needs to be restored in the next page
    
    Printer.Zoom = 100 / PrintPreview1.ScalePercent * 100
    Printer.Print "All page the same size, no matter scale"
    Printer.PaintPicture Picture1.Picture, 0, 500
    Printer.CurrentY = 2700
    Printer.Print "Boat in the middle of the sea"
    
    ' Page 5
    ' Drawing
    Printer.NewPage
    Printer.Zoom = 100
    
    Str = "Drawing" ' title
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.FontUnderline = True
    Printer.Print Str & vbCrLf
    Printer.FontUnderline = False
    
    ' Circle centered horizontally
    Printer.DrawWidth = 10
    Printer.Circle (Printer.ScaleWidth / 2, 2000), 1500, vbRed
    
    ' Rectangle at left
    Printer.Line (0, 4000)-(3000, 6000), vbBlue, B
    
    ' Filled rectangle at right
    Printer.Line (Printer.ScaleWidth - 3000, 4000)-(Printer.ScaleWidth, 6000), vbGreen, BF
    
    ' Triangle drawn with lines, horizontally centered at bottom
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
End Sub

