VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Remember preferences"
   ClientHeight    =   6732
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   5436
   LinkTopic       =   "Form1"
   ScaleHeight     =   6732
   ScaleWidth      =   5436
   Begin VB.CommandButton cmdReport3 
      Caption         =   "Print Report 3"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   576
      TabIndex        =   5
      Top             =   1272
      Width           =   1812
   End
   Begin VB.CommandButton cmdReport2 
      Caption         =   "Print Report 2"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   576
      TabIndex        =   4
      Top             =   768
      Width           =   1812
   End
   Begin VB.PictureBox Picture1 
      Height          =   372
      Left            =   4416
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   324
      ScaleWidth      =   348
      TabIndex        =   3
      Top             =   4848
      Visible         =   0   'False
      Width           =   396
   End
   Begin VB.CommandButton cmdReport1 
      Caption         =   "Print Report 1"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   552
      TabIndex        =   0
      Top             =   288
      Width           =   1812
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   4248
      Top             =   384
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label4 
      Caption         =   $"Form1.frx":186F2
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1356
      Left            =   240
      TabIndex        =   7
      Top             =   5112
      Width           =   5004
   End
   Begin VB.Label Label3 
      Caption         =   "The user preferences to be remembered are Orientation, Paper size, Scale, Color/Greyscale, Etc."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   564
      Left            =   216
      TabIndex        =   6
      Top             =   2016
      Width           =   5004
   End
   Begin VB.Label Label2 
      Caption         =   $"Form1.frx":1880C
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   972
      Left            =   240
      TabIndex        =   2
      Top             =   4056
      Width           =   5004
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":188CA
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1236
      Left            =   216
      TabIndex        =   1
      Top             =   2712
      Width           =   5004
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdReport1_Click()
    PrintPreview1.ReportID = "r1" ' this can be any string
    PrintPreview1.ShowPreview
End Sub

Private Sub cmdReport2_Click()
    PrintPreview1.ReportID = "r2" ' this can be any string
    PrintPreview1.ShowPreview
End Sub

Private Sub cmdReport3_Click()
    PrintPreview1.ReportID = "r3" ' this can be any string
    PrintPreview1.ShowPreview
End Sub

Private Sub Form_Load()
    PrintPreview1.DeleteAllUserPreferences
End Sub

Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    ' we could have used a variable for the Select Case
    ' but the ReportID property is used here because we already need to set it for saving the preferences per report,
    ' so we already had it
    
    Select Case PrintPreview1.ReportID
        Case "r1"
            PrintReport1
        Case "r2"
            PrintReport2
        Case "r3"
            PrintReport3
    End Select
End Sub

Private Sub PrintReport1()
    ' For Report1 we use code taken from Sample 1
    
    Printer.FontSize = 24
    Printer.Print "Hello World!"
End Sub

Private Sub PrintReport2()
    Dim Str As String
    
    ' For Report2 we use code taken from Sample 2
    
    ' Text positioning
    
    Printer.FontSize = 18
    Printer.FontBold = True
    
    'The following code centers the title
    Str = "CENTERED TITLE"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.Print Str
    Printer.Print vbCrLf ' line feed to have some space with the next printing
    
    Printer.FontSize = 12
    Printer.FontBold = False
    
    ' Text positioned at left
    Printer.Print "Left positioned";
    
    ' Text positioned at right
    Str = "Right positioned"
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text positioned at bottom left
    Str = "Bottom left"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.Print Str
    
    ' Text positioned at bottom right
    Str = "Bottom right"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text at center of page
    Str = "Page centered"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.CurrentY = (Printer.ScaleHeight - Printer.TextHeight(Str)) / 2
    Printer.Print Str
    
    
    ' Page 2
    ' Image positioning
    Printer.NewPage
    
    ' Left top
    Printer.PaintPicture Picture1.Picture, 0, 0
    
    ' Right top
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), 0

    ' Left Bottom
    Printer.PaintPicture Picture1.Picture, 0, Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Right Bottom
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Centered in page
    Printer.PaintPicture Picture1.Picture, (Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode)) / 2, (Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)) / 2

    
    ' Page 3
    ' Some elements of always the same size, no matter the scale the user sets
    Printer.NewPage
    Printer.Print "Some elements keep their size"
    Printer.Print "(regardless of scale)"

    Printer.FontSize = 24 * 100 / PrintPreview1.ScalePercent
    
    Printer.Print
    Printer.Print
    Printer.Print ; "Scale independent text size"
    
    Printer.FontSize = 12 ' restore the font size to old value of 12
    Printer.Print "Variable size text"
    
    ' Fixed size image
    Dim Proportion As Single
    
    Printer.Print
    Printer.Print
    Printer.Print "Scale independent image size:"
    
    ' Image width of always half page width (the margins are not taken into account) and horizontally centered
    Proportion = Printer.ScaleWidth / 2 / Picture1.Picture.Width
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth / 4, Printer.CurrentY + 500, Picture1.Picture.Width * Proportion, Picture1.Picture.Height * Proportion
    
    ' Page 4
    Printer.NewPage
    ' All page os fixed size, regardless of the sacle the user has set
    ' Notes:
    ' This technique can be used for full pages, because it changes Printer.Zoom, and it can be changed after the pages is created
    ' Printer.Zoom needs to be restored in the next page
    
    Printer.Zoom = 100 / PrintPreview1.ScalePercent * 100
    Printer.Print "All page the same size, no matter scale"
    Printer.PaintPicture Picture1.Picture, 0, 500
    Printer.CurrentY = 2700
    Printer.Print "Boat in the middle of the sea"
    
    ' Page 5
    ' Drawing
    Printer.NewPage
    Printer.Zoom = 100
    
    Str = "Drawing" ' title
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.FontUnderline = True
    Printer.Print Str & vbCrLf
    Printer.FontUnderline = False
    
    ' Circle centered horizontally
    Printer.DrawWidth = 10
    Printer.Circle (Printer.ScaleWidth / 2, 2000), 1500, vbRed
    
    ' Rectangle at left
    Printer.Line (0, 4000)-(3000, 6000), vbBlue, B
    
    ' Filled rectangle at right
    Printer.Line (Printer.ScaleWidth - 3000, 4000)-(Printer.ScaleWidth, 6000), vbGreen, BF
    
    ' Triangle drawn with lines, horizontally centered at bottom
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
End Sub

Private Sub PrintReport3()
    Dim c As Long
    
    ' For Report3 we use code taken from Sample 7
    
    ' This code simply adds some pages
    Printer.FontSize = 18
    Printer.Print "This is page 1"
    For c = 2 To 30
        Printer.NewPage
        Printer.Print "This is page " & c
    Next c
End Sub

