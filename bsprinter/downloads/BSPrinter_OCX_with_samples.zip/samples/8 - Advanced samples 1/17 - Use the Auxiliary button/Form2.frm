VERSION 5.00
Begin VB.Form Form2 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Select columns to print"
   ClientHeight    =   3708
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   4860
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3708
   ScaleWidth      =   4860
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Height          =   396
      Left            =   936
      TabIndex        =   2
      Top             =   3168
      Width           =   1572
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "Cancel"
      Height          =   396
      Left            =   2856
      TabIndex        =   1
      Top             =   3168
      Width           =   1572
   End
   Begin VB.ListBox List1 
      Height          =   2928
      Left            =   96
      Style           =   1  'Checkbox
      TabIndex        =   0
      Top             =   96
      Width           =   4668
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public Canceled As Boolean
Private mColumns() As Boolean

Private Sub cmdCancel_Click()
    Canceled = True
    Unload Me
End Sub

Private Sub cmdOK_Click()
    Dim c As Long
    
    ReDim mColumns(100) ' some number not to reach
    For c = 0 To List1.ListCount - 1
        If List1.Selected(c) Then
            mColumns(List1.ItemData(c)) = True
        End If
    Next c
    Unload Me
End Sub

Private Sub List1_ItemCheck(Item As Integer)
    Dim c As Long
    Dim iCheckedCount As Long
    
    For c = 0 To List1.ListCount - 1
        If List1.Selected(c) Then
            iCheckedCount = iCheckedCount + 1
        End If
    Next c
    If iCheckedCount = 0 Then
        MsgBox "At least one item must be selected.", vbExclamation
        List1.Selected(Item) = True
    End If
End Sub

Public Function GetColumnVisible(nColumn As Long) As BookmarkEnum
    GetColumnVisible = mColumns(nColumn)
End Function
