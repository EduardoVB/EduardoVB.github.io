VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Auxiliary button sample"
   ClientHeight    =   8112
   ClientLeft      =   2328
   ClientTop       =   888
   ClientWidth     =   9012
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   8112
   ScaleWidth      =   9012
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MSHFlexGrid1 
      Height          =   4380
      Left            =   120
      TabIndex        =   3
      Top             =   480
      Width           =   8724
      _ExtentX        =   15388
      _ExtentY        =   7726
      _Version        =   393216
      ScrollTrack     =   -1  'True
      ScrollBars      =   2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Narrow"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _NumberOfBands  =   1
      _Band(0).Cols   =   2
   End
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   6888
      TabIndex        =   2
      Top             =   7560
      Width           =   1572
   End
   Begin VB.CommandButton cmdPrint 
      Caption         =   "Print"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   504
      TabIndex        =   0
      Top             =   7560
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   2448
      Top             =   7536
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label4 
      Caption         =   $"Form1.frx":00A0
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   564
      Left            =   144
      TabIndex        =   8
      Top             =   6926
      Width           =   8604
   End
   Begin VB.Label Label2 
      Caption         =   $"Form1.frx":0160
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   900
      Left            =   144
      TabIndex        =   7
      Top             =   5666
      Width           =   8604
   End
   Begin VB.Label Label5 
      Caption         =   "These images can also be loaded by code using the property 'ToolbarButtonPicture'."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   348
      Left            =   144
      TabIndex        =   6
      Top             =   6602
      Width           =   8604
   End
   Begin VB.Label lblTitle2 
      Caption         =   "(in thousands)"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   3552
      TabIndex        =   5
      Top             =   168
      Width           =   2172
   End
   Begin VB.Label lblTitle 
      AutoSize        =   -1  'True
      Caption         =   "World population by country"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   10.2
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   252
      Left            =   312
      TabIndex        =   4
      Top             =   120
      Width           =   2952
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":02B0
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   660
      Left            =   144
      TabIndex        =   1
      Top             =   4944
      Width           =   8604
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private mColumnsToPrint() As Boolean

Private Sub Form_Load()
    ' we need to set AuxiliaryButtonVisible property to True and we want to set the ToolTip text of the button.
    ' these properties are also available at design time
    PrintPreview1.AuxiliaryButtonVisible = True
    PrintPreview1.AuxiliaryButtonToolTipText = "Select columns"
    
    ' load the data on the grid
    LoadDataOnGrid
    
    Dim c As Long
    ReDim mColumnsToPrint(MSHFlexGrid1.Cols - 1)
    For c = 0 To MSHFlexGrid1.Cols - 1
        mColumnsToPrint(c) = True
    Next c
End Sub

Private Sub cmdPrint_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
    
    ' restore the widths of the columns (possible) hided by the user
    SetColumnsWidths
End Sub

Private Sub cmdClose_Click()
    Unload Me
End Sub

Private Sub PrintPreview1_AuxiliaryButtonClick(UpdateReport As Boolean)
    Dim c As Long
    
    For c = 0 To MSHFlexGrid1.Cols - 1
        If c <> 0 Then ' the first column (ID) is always hidden
            ' add each column to the list on Form2
            Form2.List1.AddItem MSHFlexGrid1.TextMatrix(0, c)
            Form2.List1.ItemData(Form2.List1.NewIndex) = c
            Form2.List1.Selected(Form2.List1.NewIndex) = mColumnsToPrint(c)
        End If
    Next c
    Form2.Show 1
    If Form2.Canceled Then
        UpdateReport = False ' the user canceled, nothing changed, we don't need the print preview window to update the report
    Else
        ' hide the columns that the user don't want to print by setting their widths to 0
        For c = 1 To MSHFlexGrid1.Cols - 1
            mColumnsToPrint(c) = Form2.GetColumnVisible(c)
            If mColumnsToPrint(c) Then
                If c = 2 Then
                    MSHFlexGrid1.ColWidth(c) = 2900
                Else
                    MSHFlexGrid1.ColWidth(c) = 1100
                End If
            Else
                MSHFlexGrid1.ColWidth(c) = 0
            End If
        Next c
    End If
    Set Form2 = Nothing
End Sub

Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    ' Code for printing the report
    
    ' Title
    Printer.FontSize = 18
    Printer.FontBold = True
    Printer.Print lblTitle.Caption
    Printer.FontSize = 12
    Printer.Print lblTitle2.Caption
    Printer.Print
    Printer.FontBold = False
    
    ' Print the grid
    PrintPreview1.PrintGrid MSHFlexGrid1 ' (this is the only code line needed for printing the grid)
    
    Printer.Print
    Printer.Print "Data published by United Nations"
    Printer.FontSize = 10
    Printer.Print "https://population.un.org/wpp/Download/Standard/Population/"
End Sub

Private Sub LoadDataOnGrid()
    Dim cn As New ADODB.Connection
    Dim rs As New ADODB.Recordset
    Dim c As Long
    
    ' Load data on the grid
    cn.Provider = "Microsoft.Jet.OLEDB.4.0"
    cn.Open App.Path & "\PopBD.mdb", "", ""
    rs.Open "Select * From World_Population", cn, adOpenStatic
    
    MSHFlexGrid1.FixedCols = 0
    Set MSHFlexGrid1.DataSource = rs
    
    SetColumnsWidths
    
    MSHFlexGrid1.TextMatrix(0, 1) = "Country code"
    MSHFlexGrid1.TextMatrix(0, 2) = "Country Name"
    MSHFlexGrid1.TextMatrix(0, 3) = "1960"
    MSHFlexGrid1.TextMatrix(0, 4) = "1980"
    MSHFlexGrid1.TextMatrix(0, 5) = "2000"
    MSHFlexGrid1.TextMatrix(0, 6) = "2020"
    MSHFlexGrid1.Row = 0
    For c = 0 To MSHFlexGrid1.Cols - 1
        MSHFlexGrid1.Col = c
        MSHFlexGrid1.CellFontBold = True
        MSHFlexGrid1.CellAlignment = flexAlignCenterCenter
    Next c
    MSHFlexGrid1.ColAlignment(1) = flexAlignLeftCenter
End Sub

Private Sub SetColumnsWidths()
    Dim c As Long
    
    For c = 0 To MSHFlexGrid1.Cols - 1
        If c = 2 Then
            MSHFlexGrid1.ColWidth(c) = 2900
        ElseIf c = 0 Then
            MSHFlexGrid1.ColWidth(c) = 0
        Else
            MSHFlexGrid1.ColWidth(c) = 1100
        End If
    Next
End Sub
