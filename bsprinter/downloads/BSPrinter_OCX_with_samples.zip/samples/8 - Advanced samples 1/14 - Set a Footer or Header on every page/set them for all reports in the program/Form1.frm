VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Header and/or footer global"
   ClientHeight    =   6180
   ClientLeft      =   780
   ClientTop       =   1944
   ClientWidth     =   5088
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   6180
   ScaleWidth      =   5088
   Begin VB.CommandButton Command3 
      Caption         =   "Remove header"
      Height          =   612
      Left            =   800
      TabIndex        =   7
      Top             =   5328
      Width           =   1572
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Show Form3"
      Height          =   612
      Left            =   800
      TabIndex        =   3
      Top             =   1176
      Width           =   1572
   End
   Begin VB.PictureBox Picture2 
      Height          =   564
      Left            =   2664
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   516
      ScaleWidth      =   2100
      TabIndex        =   1
      Top             =   120
      Visible         =   0   'False
      Width           =   2148
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show Form2"
      Height          =   612
      Left            =   800
      TabIndex        =   0
      Top             =   408
      Width           =   1572
   End
   Begin VB.Label Label4 
      Caption         =   "Using Setheader and SetFooter again, will replace the current setting."
      Height          =   564
      Left            =   312
      TabIndex        =   6
      Top             =   3960
      Width           =   4632
   End
   Begin VB.Label Label2 
      Caption         =   "To remove a header or footer use the SetHeader and SetFooter methods with no parameters."
      Height          =   564
      Left            =   312
      TabIndex        =   5
      Top             =   4608
      Width           =   4632
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":97F6
      Height          =   756
      Left            =   312
      TabIndex        =   4
      Top             =   3096
      Width           =   4632
   End
   Begin VB.Label Label3 
      Caption         =   $"Form1.frx":9890
      Height          =   756
      Left            =   312
      TabIndex        =   2
      Top             =   2232
      Width           =   4632
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    Form2.Show
End Sub

Private Sub Command2_Click()
    Form3.Show
End Sub

Private Sub Command3_Click()
    PrintPreview.SetHeader
End Sub

Private Sub Form_Load()
    Dim oFont As StdFont
    
    ' set an image as a header, positioned at right
    ' note that it uses the PrintPreview global object instead of the PrintPreview control
    ' to set the header and footer
    PrintPreview.SetHeader Picture2.Picture, bsHPosRight, , , , , 0.75
    
    ' text for a footer, changing the font size and the color
    Set oFont = New StdFont
    oFont.Size = 18
    PrintPreview.SetFooter "Text for the footer", , , , oFont, vbBlue
End Sub
