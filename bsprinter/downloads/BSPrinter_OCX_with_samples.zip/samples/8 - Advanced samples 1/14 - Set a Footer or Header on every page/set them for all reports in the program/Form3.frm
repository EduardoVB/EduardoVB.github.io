VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form3 
   Caption         =   "Form3"
   ClientHeight    =   4224
   ClientLeft      =   11244
   ClientTop       =   1956
   ClientWidth     =   5160
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form3"
   ScaleHeight     =   4224
   ScaleWidth      =   5160
   Begin VB.CommandButton Command2 
      Caption         =   "Show report 4"
      Height          =   612
      Left            =   800
      TabIndex        =   1
      Top             =   2016
      Width           =   1572
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show report 3"
      Height          =   612
      Left            =   800
      TabIndex        =   0
      Top             =   768
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3200
      Top             =   744
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin BSPrinter.PrintPreview PrintPreview2 
      Left            =   3200
      Top             =   2064
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label3 
      Caption         =   "Some more reports"
      Height          =   756
      Left            =   288
      TabIndex        =   2
      Top             =   2976
      Width           =   4632
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    PrintPreview1.ShowPreview
End Sub

Private Sub Command2_Click()
    PrintPreview2.ShowPreview
End Sub

Public Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim c As Long
    
    Printer.FontSize = 22
    PrintPreview1.PrintEx "Circles", , , , , , bsAlignCenterTop
    
    Printer.DrawWidth = 5
    
    For c = 1 To 2000 Step 100
        Printer.Circle (Printer.ScaleWidth / 2, 3000), c, vbRed
    Next c
End Sub

Public Sub PrintPreview2_PrepareReport(Cancel As Boolean)
    Dim c As Long
    
    Printer.FontSize = 22
    PrintPreview2.PrintEx "Squares", , , , , , bsAlignCenterTop
    
    Printer.DrawWidth = 5
    
    For c = 1 To 2000 Step 100
        Printer.Line (Printer.ScaleWidth / 2 - c, 3000 - c)-(Printer.ScaleWidth / 2 + c, 3000 + c), vbBlue, B
    Next c
End Sub
