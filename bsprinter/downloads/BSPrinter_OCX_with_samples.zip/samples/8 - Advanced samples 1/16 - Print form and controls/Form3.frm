VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form Form3 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Print controls"
   ClientHeight    =   6240
   ClientLeft      =   6264
   ClientTop       =   1200
   ClientWidth     =   5364
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6240
   ScaleWidth      =   5364
   ShowInTaskbar   =   0   'False
   Begin VB.ListBox List1 
      Height          =   2208
      Left            =   264
      TabIndex        =   3
      Top             =   2976
      Width           =   4860
   End
   Begin ComctlLib.TreeView TreeView1 
      Height          =   2076
      Left            =   264
      TabIndex        =   2
      Top             =   432
      Width           =   4860
      _ExtentX        =   8573
      _ExtentY        =   3662
      _Version        =   327682
      Style           =   7
      Appearance      =   1
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   2400
      Top             =   5472
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Close"
      Height          =   468
      Left            =   3096
      TabIndex        =   1
      Top             =   5496
      Width           =   1620
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Print"
      Height          =   468
      Left            =   624
      TabIndex        =   0
      Top             =   5496
      Width           =   1620
   End
   Begin VB.Label Label2 
      Caption         =   "ListBox:"
      Height          =   276
      Left            =   264
      TabIndex        =   5
      Top             =   2640
      Width           =   2100
   End
   Begin VB.Label Label1 
      Caption         =   "TreeView:"
      Height          =   276
      Left            =   264
      TabIndex        =   4
      Top             =   120
      Width           =   2100
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    PrintPreview1.ShowPreview
End Sub

Private Sub Command2_Click()
    Unload Me
End Sub

Private Sub Form_Load()
    LoadTRVSample
    LoadLBSample
End Sub

Public Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Printer.FontSize = 16
    PrintPreview1.PrintEx "Print TreeView", , , , , , bsAlignCenterCenter
    Printer.Print
    PrintPreview1.PrintWindow TreeView1.hWnd, , , , , True
    Printer.Print
    PrintPreview1.PrintEx "Print ListBox", , , , , , bsAlignCenterCenter
    Printer.Print
    PrintPreview1.PrintWindow List1.hWnd, , , , , True
End Sub

Private Sub LoadTRVSample()
    Dim i As Integer
    
    ' Add some root level items
    For i = 1 To 5
        TreeView1.Nodes.Add , , "ROOT" & i, "Root Item " & i
    Next
    
    ' Now add some children
    For i = 1 To 5
        With TreeView1.Nodes
            .Add "ROOT1", tvwChild, "ROOT1CHILD" & i, "Child Item " & i
            .Add "ROOT2", tvwChild, "ROOT2CHILD" & i, "Child Item " & i
            .Add "ROOT3", tvwChild, "ROOT3CHILD" & i, "Child Item " & i
            .Add "ROOT4", tvwChild, "ROOT4CHILD" & i, "Child Item " & i
            .Add "ROOT5", tvwChild, "ROOT5CHILD" & i, "Child Item " & i
        End With
    Next
    
    ' Now Add Some Grand-Children
    For i = 1 To 5
        With TreeView1.Nodes
            .Add "ROOT1CHILD2", tvwChild, , "Grand Child " & i
            .Add "ROOT2CHILD2", tvwChild, , "Grand Child " & i
            .Add "ROOT3CHILD2", tvwChild, , "Grand Child " & i
            .Add "ROOT4CHILD2", tvwChild, , "Grand Child " & i
            .Add "ROOT5CHILD2", tvwChild, , "Grand Child " & i
        End With
    Next
    TreeView1.Nodes("ROOT1").Expanded = True
End Sub

Private Sub LoadLBSample()
    Dim c As Long
    
    For c = 1 To 20
        List1.AddItem "Item " & c & " ---> " & Rnd
    Next
End Sub

