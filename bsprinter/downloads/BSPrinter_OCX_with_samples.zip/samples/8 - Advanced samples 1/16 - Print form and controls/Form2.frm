VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form2 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Print form"
   ClientHeight    =   5808
   ClientLeft      =   6264
   ClientTop       =   1200
   ClientWidth     =   5364
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5808
   ScaleWidth      =   5364
   ShowInTaskbar   =   0   'False
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3672
      Top             =   3288
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Close"
      Height          =   468
      Left            =   3120
      TabIndex        =   10
      Top             =   5040
      Width           =   1620
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Print"
      Height          =   468
      Left            =   648
      TabIndex        =   9
      Top             =   5040
      Width           =   1620
   End
   Begin VB.PictureBox Picture1 
      AutoSize        =   -1  'True
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1944
      Left            =   528
      Picture         =   "Form2.frx":00A0
      ScaleHeight     =   1896
      ScaleWidth      =   2520
      TabIndex        =   8
      Top             =   2688
      Width           =   2568
   End
   Begin VB.TextBox Text4 
      Height          =   396
      Left            =   1968
      TabIndex        =   7
      Text            =   "Value 4"
      Top             =   1704
      Width           =   1548
   End
   Begin VB.TextBox Text3 
      Height          =   396
      Left            =   1968
      TabIndex        =   5
      Text            =   "Value 3"
      Top             =   1248
      Width           =   1548
   End
   Begin VB.TextBox Text2 
      Height          =   396
      Left            =   1968
      TabIndex        =   3
      Text            =   "Value 2"
      Top             =   792
      Width           =   1548
   End
   Begin VB.TextBox Text1 
      Height          =   396
      Left            =   1968
      TabIndex        =   1
      Text            =   "Value 1"
      Top             =   336
      Width           =   1548
   End
   Begin VB.Label Label5 
      Caption         =   "Photo:"
      Height          =   228
      Left            =   552
      TabIndex        =   11
      Top             =   2400
      Width           =   1236
   End
   Begin VB.Label Label4 
      Alignment       =   1  'Right Justify
      Caption         =   "Field 4:"
      Height          =   348
      Left            =   504
      TabIndex        =   6
      Top             =   1728
      Width           =   1236
   End
   Begin VB.Label Label3 
      Alignment       =   1  'Right Justify
      Caption         =   "Field 3:"
      Height          =   348
      Left            =   504
      TabIndex        =   4
      Top             =   1272
      Width           =   1236
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Caption         =   "Field 2:"
      Height          =   348
      Left            =   504
      TabIndex        =   2
      Top             =   816
      Width           =   1236
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Caption         =   "Field 1:"
      Height          =   348
      Left            =   504
      TabIndex        =   0
      Top             =   360
      Width           =   1236
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    PrintPreview1.ShowPreview
End Sub

Private Sub Command2_Click()
    Unload Me
End Sub

Public Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Printer.FontSize = 16
    PrintPreview1.PrintEx "Print form sample", , , , , , bsAlignCenterCenter
    Printer.Print
    PrintPreview1.PrintForm Me
End Sub
