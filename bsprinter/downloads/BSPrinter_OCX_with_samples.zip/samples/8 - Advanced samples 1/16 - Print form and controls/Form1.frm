VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Print forms and controls"
   ClientHeight    =   2520
   ClientLeft      =   936
   ClientTop       =   1932
   ClientWidth     =   4296
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   2520
   ScaleWidth      =   4296
   Begin VB.CommandButton Command2 
      Caption         =   "Form3: Print controls"
      Height          =   516
      Left            =   936
      TabIndex        =   1
      Top             =   1344
      Width           =   2364
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Form2: Print form"
      Height          =   516
      Left            =   936
      TabIndex        =   0
      Top             =   720
      Width           =   2364
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    Form2.Show 1
End Sub

Private Sub Command2_Click()
    Form3.Show 1
End Sub
