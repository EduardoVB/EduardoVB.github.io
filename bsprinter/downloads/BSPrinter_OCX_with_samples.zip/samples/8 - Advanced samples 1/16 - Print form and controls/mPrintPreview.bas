Attribute VB_Name = "mPrintPreview"
Option Explicit

Private Type RECT
    Left As Long
    Top As Long
    Right As Long
    Bottom As Long
End Type

Private Declare Function GetWindowRect Lib "user32" (ByVal hWnd As Long, lpRect As RECT) As Long
Private Declare Function SetWindowPos Lib "user32" (ByVal hWnd As Long, ByVal hWndInsertAfter As Long, ByVal x As Long, ByVal y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long

Private Const SWP_NOACTIVATE = &H10&
Private Const SWP_NOMOVE As Long = &H2
Private Const SWP_NOZORDER = &H4
Private Const PW_CLIENTONLY As Long = &H1&

Private Declare Function PrintWindow Lib "user32" (ByVal hWnd As Long, ByVal hdcBlt As Long, ByVal nFlags As Long) As Long

'This fucntion returns the image of a window with its controls
Public Function GetWindowImage(hWnd As Long, picAux As PictureBox, Optional ClientOnly As Boolean) As StdPicture
    Dim iRc As RECT
    
    ' PicAux size:
    GetWindowRect hWnd, iRc
    SetWindowPos picAux.hWnd, 0, 0, 0, iRc.Right - iRc.Left, iRc.Bottom - iRc.Top, SWP_NOZORDER Or SWP_NOMOVE Or SWP_NOACTIVATE
    picAux.AutoRedraw = True
    
    ' capture the image
    PrintWindow hWnd, picAux.hDC, IIf(ClientOnly, PW_CLIENTONLY, 0)
    
    ' set the return variable
    Set GetWindowImage = picAux.Image
    picAux.Cls
End Function

'Needed for print preview:
Public Property Get Printer() As Printer
    Set Printer = PrinterReplacement
End Property

Public Property Set Printer(nPrinter As Printer)
    Set PrinterReplacement = nPrinter
End Property

