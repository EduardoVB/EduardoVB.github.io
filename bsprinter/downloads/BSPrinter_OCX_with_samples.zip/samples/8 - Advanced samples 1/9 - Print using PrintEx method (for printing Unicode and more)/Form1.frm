VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Print using PrintEx method"
   ClientHeight    =   5052
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   5160
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   5052
   ScaleWidth      =   5160
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview window"
      Height          =   612
      Left            =   984
      TabIndex        =   0
      Top             =   456
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3288
      Top             =   456
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label5 
      Caption         =   "For further details about the methods, please read the documentation."
      Height          =   516
      Left            =   300
      TabIndex        =   5
      Top             =   4296
      Width           =   4620
   End
   Begin VB.Label Label4 
      Caption         =   "Check the code."
      Height          =   348
      Left            =   300
      TabIndex        =   4
      Top             =   3840
      Width           =   4620
   End
   Begin VB.Label Label3 
      Caption         =   $"Form1.frx":00A0
      Height          =   780
      Left            =   300
      TabIndex        =   3
      Top             =   2952
      Width           =   4620
   End
   Begin VB.Label Label2 
      Caption         =   "Another advantage is that unlike the Printer.Print method, PrintPreview1.PrintEx has Unicode support."
      Height          =   540
      Left            =   300
      TabIndex        =   2
      Top             =   2280
      Width           =   4620
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":012F
      Height          =   780
      Left            =   300
      TabIndex        =   1
      Top             =   1368
      Width           =   4620
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

' code taken from Sample 2, but modified to use PrintEx method
Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    
    ' Text positioning
    
    Printer.FontSize = 18
    Printer.FontBold = True
    
    ' The following code centers the title
    PrintPreview1.PrintEx "CENTERED TITLE", , 0, , Printer.ScaleWidth, , bsAlignCenterTop
    
    Printer.FontSize = 12
    Printer.FontBold = False
    
    ' Text positioned at left
    PrintPreview1.PrintEx "Left positioned", bsNoLineFeed
    
    ' Text positioned at right
    PrintPreview1.PrintEx "Right positioned", , 0, , Printer.ScaleWidth, , bsAlignRightTop
    
    ' Text positioned at bottom left
    PrintPreview1.PrintEx "Bottom left", , 0, 0, Printer.ScaleWidth, Printer.ScaleHeight, bsAlignLeftBottom
    
    ' Text positioned at bottom right
    PrintPreview1.PrintEx "Bottom right", , 0, 0, Printer.ScaleWidth, Printer.ScaleHeight, bsAlignRightBottom
    
    ' Text at center of page
    PrintPreview1.PrintEx "Page centered", , 0, 0, Printer.ScaleWidth, Printer.ScaleHeight, bsAlignCenterCenter
    
    ' page 2
    Printer.NewPage
    
    Dim Str As String
    Dim TextWidth As Single
    Dim TextHeight As Single
    Dim X As Single
    Dim Y As Single
    
    ' position a text in an specific position, set a background color and make a box around it
    
    ' set the position
    X = Printer.ScaleWidth / 2
    Y = Printer.ScaleHeight / 3
    Str = "Text positioned at 1/3 of page height and 1/2 or page width"
    
    ' measure the text
    TextWidth = PrintPreview1.TextWidthEx(Str, , X, Y, , bsAlignCenterCenter)
    TextHeight = PrintPreview1.TextHeightEx(Str, , X, Y, , bsAlignCenterCenter)
    
    ' draw the background
    Printer.Line (X, Y)-(X + TextWidth, Y + TextHeight), vbYellow, BF
    ' draw a blue rectangle as a border
    Printer.DrawWidth = 10
    Printer.Line (X, Y)-(X + TextWidth, Y + TextHeight), vbBlue, B
    
    ' print the text
    PrintPreview1.PrintEx Str, , X, Y, TextWidth, TextHeight, bsAlignCenterCenter

End Sub

