VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.0#0"; "RICHTX32.OCX"
Begin VB.Form Form1 
   Caption         =   "RichTextBox sample"
   ClientHeight    =   7572
   ClientLeft      =   2628
   ClientTop       =   2172
   ClientWidth     =   9012
   LinkTopic       =   "Form1"
   ScaleHeight     =   7572
   ScaleWidth      =   9012
   Begin VB.CommandButton cmdPrint 
      Caption         =   "Print"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   600
      TabIndex        =   1
      Top             =   6960
      Width           =   1572
   End
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   396
      Left            =   6864
      TabIndex        =   0
      Top             =   6960
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   2712
      Top             =   6960
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin RichTextLib.RichTextBox RichTextBox1 
      Height          =   5124
      Left            =   144
      TabIndex        =   2
      Top             =   144
      Width           =   7860
      _ExtentX        =   13864
      _ExtentY        =   9038
      _Version        =   393217
      ScrollBars      =   2
      AutoVerbMenu    =   -1  'True
      TextRTF         =   $"Form1.frx":0000
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdPrint_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    ' the following is the only line needed to print the RichTextBox control
    PrintPreview1.PrintRichTextBox RichTextBox1
End Sub

Private Sub Form_Load()
    RichTextBox1.LoadFile (App.Path & "\PPCtl_Reference.rtf")
End Sub

Private Sub Form_Resize()
    ' position controls
    RichTextBox1.Move 60, 60, Me.ScaleWidth - 120, Me.ScaleHeight - 850
    cmdPrint.Top = Me.ScaleHeight - 600
    cmdClose.Top = cmdPrint.Top
    cmdClose.Left = Me.ScaleWidth - cmdClose.Width - 600
End Sub

Private Sub cmdClose_Click()
    Unload Me
End Sub


