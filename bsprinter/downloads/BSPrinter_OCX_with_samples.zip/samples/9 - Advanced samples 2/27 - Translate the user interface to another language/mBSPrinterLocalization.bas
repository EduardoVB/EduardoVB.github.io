Attribute VB_Name = "mBSPrinterLocalization"
Option Explicit

Private Const bsLang_FINNISH = 11

'' Language constants full list
'Private Enum BSLanguageIDAllConstants
'    bsLang_ARABIC = 1
'    bsLang_BULGARIAN = 2
'    bsLang_CATALAN = 3
'    bsLang_CHINESE_SIMPLIFIED = 4
'    bsLang_CZECH = 5
'    bsLang_DANISH = 6
'    bsLang_GERMAN = 7
'    bsLang_GREEK = 8
'    bsLang_ENGLISH = 9
'    bsLang_SPANISH = 10
'    bsLang_FINNISH = 11
'    bsLang_FRENCH = 12
'    bsLang_HEBREW = 13
'    bsLang_HUNGARIAN = 14
'    bsLang_ICELANDIC = 15
'    bsLang_ITALIAN = 16
'    bsLang_JAPANESE = 17
'    bsLang_KOREAN = 18
'    bsLang_DUTCH = 19
'    bsLang_NORWEGIAN = 20
'    bsLang_POLISH = 21
'    bsLang_PORTUGUESE = 22
'    bsLang_ROMANSH = 23
'    bsLang_ROMANIAN = 24
'    bsLang_RUSSIAN = 25
'    bsLang_BOSNIAN_SERBIAN_CROATIAN = 26
'    bsLang_SLOVAK = 27
'    bsLang_ALBANIAN = 28
'    bsLang_SWEDISH = 29
'    bsLang_THAI = 30
'    bsLang_TURKISH = 31
'    bsLang_URDU = 32
'    bsLang_INDONESIAN = 33
'    bsLang_UKRAINIAN = 34
'    bsLang_BELARUSIAN = 35
'    bsLang_SLOVENIAN = 36
'    bsLang_ESTONIAN = 37
'    bsLang_LATVIAN = 38
'    bsLang_LITHUANIAN = 39
'    bsLang_TAJIK = 40
'    bsLang_FARSI_PERSIAN = 41
'    bsLang_VIETNAMESE = 42
'    bsLang_ARMENIAN = 43
'    bsLang_AZERI = 44
'    bsLang_BASQUE = 45
'    bsLang_SORBIAN = 46
'    bsLang_MACEDONIAN = 47
'    bsLang_TSWANA = 50
'    bsLang_XHOSA = 52
'    bsLang_ZULU = 53
'    bsLang_AFRIKAANS = 54
'    bsLang_GEORGIAN = 55
'    bsLang_FAEROESE = 56
'    bsLang_HINDI = 57
'    bsLang_MALTESE = 58
'    bsLang_SAMI = 59
'    bsLang_IRISH = 60
'    bsLang_MALAY = 62
'    bsLang_KAZAK = 63
'    bsLang_KYRGYZ = 64
'    bsLang_SWAHILI = 65
'    bsLang_TURKMEN = 66
'    bsLang_UZBEK = 67
'    bsLang_TATAR = 68
'    bsLang_BENGALI = 69
'    bsLang_PUNJABI = 70
'    bsLang_GUJARATI = 71
'    bsLang_ORIYA = 72
'    bsLang_TAMIL = 73
'    bsLang_TELUGU = 74
'    bsLang_KANNADA = 75
'    bsLang_MALAYALAM = 76
'    bsLang_ASSAMESE = 77
'    bsLang_MARATHI = 78
'    bsLang_SANSKRIT = 79
'    bsLang_MONGOLIAN = 80
'    bsLang_TIBETAN = 81
'    bsLang_WELSH = 82
'    bsLang_KHMER = 83
'    bsLang_LAO = 84
'    bsLang_GALICIAN = 86
'    bsLang_KONKANI = 87
'    bsLang_MANIPURI = 88
'    bsLang_SINDHI = 89
'    bsLang_SYRIAC = 90
'    bsLang_SINHALESE = 91
'    bsLang_INUKTITUT = 93
'    bsLang_AMHARIC = 94
'    bsLang_TAMAZIGHT = 95
'    bsLang_KASHMIRI = 96
'    bsLang_NEPALI = 97
'    bsLang_FRISIAN = 98
'    bsLang_PASHTO = 99
'    bsLang_FILIPINO = 100
'    bsLang_DIVEHI = 101
'    bsLang_HAUSA = 104
'    bsLang_YORUBA = 106
'    bsLang_QUECHUA = 107
'    bsLang_SOTHO = 108
'    bsLang_BASHKIR = 109
'    bsLang_LUXEMBOURGISH = 110
'    bsLang_GREENLANDIC = 111
'    bsLang_IGBO = 112
'    bsLang_TIGRIGNA = 115
'    bsLang_YI = 120
'    bsLang_MAPUDUNGUN = 122
'    bsLang_MOHAWK = 124
'    bsLang_BRETON = 126
'    bsLang_UIGHUR = 128
'    bsLang_MAORI = 129
'    bsLang_OCCITAN = 130
'    bsLang_CORSICAN = 131
'    bsLang_ALSATIAN = 132
'    bsLang_YAKUT = 133
'    bsLang_KICHE = 134
'    bsLang_KINYARWANDA = 135
'    bsLang_WOLOF = 136
'    bsLang_DARI = 140
'    bsLang_SCOTTISH_GAELIC = 145
'    bsLang_BOSNIAN_NEUTRAL = 30746
'    bsLang_CHINESE_TRADITIONAL = 31748
'    bsLang_SERBIAN_NEUTRAL = 31770
'End Enum

' TextID constants
Private Enum BSUserInterfaceTextsIDConstants
    
    ' General
    bsPPUI_General_CloseButton_Caption = 2000
    bsPPUI_General_OKButton_Caption = 2100
    bsPPUI_General_CancelButton_Caption = 2200
    bsPPUI_General_Unnamed_FileName = 2300
    
    ' PrinterEx
    bsPPUI_General_PageNumbersFormatStrings_Count = 4000
    bsPPUI_General_PageNumbersFormatString_Item = 4100
    bsPPUI_General_PageNumbersFormatFixedStrings_Count = 4200
    bsPPUI_General_PageNumbersFormatFixedString_Item = 4300
    bsPPUI_General_PrintDocumentTooLongWarning_PageText = 4400
    bsPPUI_General_PrintDocumentTooLongWarning_MsgBoxWarning = 4500
    bsPPUI_General_PrinterNotAvailable1 = 4600
    bsPPUI_General_PrinterNotAvailable2 = 4700
    bsPPUI_General_PageNumbers_Dont_Exists_Message = 4800
    bsPPUI_General_SaveToFile_PrinterNotInstalled = 4900
    
    ' Report style names
    bsPPUI_General_GridReportStyleNames_Basic = 6000
    bsPPUI_General_GridReportStyleNames_Basic_Gray = 6100
    bsPPUI_General_GridReportStyleNames_Basic_Red = 6200
    bsPPUI_General_GridReportStyleNames_Basic_Green = 6300
    bsPPUI_General_GridReportStyleNames_Basic_Yellow = 6400
    
    bsPPUI_General_GridReportStyleNames_Modern = 8000
    bsPPUI_General_GridReportStyleNames_Modern_Gray = 8100
    bsPPUI_General_GridReportStyleNames_Modern_Red = 8200
    bsPPUI_General_GridReportStyleNames_Modern_Green = 8300
    bsPPUI_General_GridReportStyleNames_Modern_Yellow = 8400
    
    bsPPUI_General_GridReportStyleNames_Grid = 10000
    bsPPUI_General_GridReportStyleNames_Grid_Gray = 10100
    bsPPUI_General_GridReportStyleNames_Grid_Red = 10200
    bsPPUI_General_GridReportStyleNames_Grid_Green = 10300
    bsPPUI_General_GridReportStyleNames_Grid_Yellow = 10400
    
    bsPPUI_General_GridReportStyleNames_Closed = 12000
    bsPPUI_General_GridReportStyleNames_Closed_Gray = 12100
    bsPPUI_General_GridReportStyleNames_Closed_Red = 12200
    bsPPUI_General_GridReportStyleNames_Closed_Green = 12300
    bsPPUI_General_GridReportStyleNames_Closed_Yellow = 12400
    
    bsPPUI_General_GridReportStyleNames_Horizontal = 14000
    bsPPUI_General_GridReportStyleNames_Horizontal_Gray = 14100
    bsPPUI_General_GridReportStyleNames_Horizontal_Red = 14200
    bsPPUI_General_GridReportStyleNames_Horizontal_Green = 14300
    bsPPUI_General_GridReportStyleNames_Horizontal_Yellow = 14400
    
    bsPPUI_General_GridReportStyleNames_Free = 16000
    bsPPUI_General_GridReportStyleNames_Free_Gray = 16100
    bsPPUI_General_GridReportStyleNames_Free_Red = 16200
    bsPPUI_General_GridReportStyleNames_Free_Green = 16300
    bsPPUI_General_GridReportStyleNames_Free_Yellow = 16400
    
    ' PrintPreview dialog
    bsPPUI_PreviewDialog_Caption = 18000
    bsPPUI_PreviewDialog_mnuView2p_Caption = 18100
    bsPPUI_PreviewDialog_mnuView3p_Caption = 18200
    bsPPUI_PreviewDialog_mnuView6p_Caption = 18300
    bsPPUI_PreviewDialog_mnuView12p_Caption = 18400
    bsPPUI_PreviewDialog_mnuTopIconsAuto_Caption = 18500
    bsPPUI_PreviewDialog_mnuTopIconsSmall_Caption = 18600
    bsPPUI_PreviewDialog_mnuTopIconsMedium_Caption = 18700
    bsPPUI_PreviewDialog_mnuTopIconsLarge_Caption = 18800
    bsPPUI_PreviewDialog_Icons_Size_Small = 18900
    bsPPUI_PreviewDialog_Icons_Size_Medium = 19000
    bsPPUI_PreviewDialog_Icons_Size_large = 19100
    bsPPUI_PreviewDialog_mnuTopShowBottomToolbar_Caption = 19200
    bsPPUI_PreviewDialog_mnuTopShowMargins_Caption = 19300
    bsPPUI_PreviewDialog_CurrentlySelected = 19400
    bsPPUI_PreviewDialog_CurrentlyShown = 19500
    bsPPUI_PreviewDialog_lblPageOrientation_Caption = 19600
    bsPPUI_PreviewDialog_lblView_Caption = 19700
    bsPPUI_PreviewDialog_lblScale_Caption = 19800
    bsPPUI_PreviewDialog_CurrentPage_Singular_Caption = 19900
    bsPPUI_PreviewDialog_CurrentPage_Plural_Caption = 20000
    bsPPUI_PreviewDialog_PreparingDoc_Caption_LoadingPreview = 20200
    bsPPUI_PreviewDialog_PreparingDoc_Caption_PreparingDocument = 20300
    bsPPUI_PreviewDialog_cmdPrintInDefaultPrinter_Caption = 20400
    bsPPUI_PreviewDialog_cmdClose_Caption = 20500
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_Print = 20600
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_PageSetup = 20700
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_Auxiliary = 20800
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_PageNumbersOptions = 20900
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_Format = 21000
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_OrientationPortrait = 21100
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_OrientationLandscape = 21200
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_OrientationCantBeChanged = 21300
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ViewNormalSize = 21400
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ViewFullWidth = 21500
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ViewFullHeight = 21600
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ViewMultiplePages = 21700
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_DecreaseScale = 21800
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_IncreaseScale = 21900
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ShowMenu = 22000
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_FirstPage = 22100
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_PreviousPage_Singular = 22200
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_PreviousPage_Plural = 22300
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_NextPage_Singular = 22400
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_NextPage_Plural = 22500
    bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_LastPage = 22600
    bsPPUI_PreviewDialog_NonPrintableAreaText = 22700
    bsPPUI_PreviewDialog_Inches_Abbreviation = 22800
    bsPPUI_PreviewDialog_Millimeters_Abbreviation = 22900
    
    ' Progress window
    bsPPUI_ProgressWindow_lblMessage_Caption_Start_PrintPreview = 24000
    bsPPUI_ProgressWindow_lblMessage_Caption_Progress_PrintPreview = 24100
    bsPPUI_ProgressWindow_lblMessage_Caption_Start_General = 24200
    bsPPUI_ProgressWindow_lblMessage_Caption_Progress_General = 24300
    bsPPUI_ProgressWindow_MsgBox_Cancel_Preview = 24400
    
    '  FormatOptions dialog
    bsPPUI_FormatOptionsDialog_Caption = 26000
    bsPPUI_FormatOptionsDialog_TabCaption_1 = 26100
    bsPPUI_FormatOptionsDialog_TabCaption_2 = 26200
    bsPPUI_FormatOptionsDialog_lblScale_Caption = 26300
    bsPPUI_FormatOptionsDialog_lblColorMode_Caption = 26400
    bsPPUI_FormatOptionsDialog_lblPageNumbersPosition_Caption = 26500
    bsPPUI_FormatOptionsDialog_lblPageNumberFormat_Caption = 26600
    bsPPUI_FormatOptionsDialog_lblPageNumbersFont_Caption = 26700
    bsPPUI_FormatOptionsDialog_lblGridPosition_Caption = 26800
    bsPPUI_FormatOptionsDialog_cboColorMode_PrinterDefault = 26900
    bsPPUI_FormatOptionsDialog_cboColorMode_GrayScale = 27000
    bsPPUI_FormatOptionsDialog_cboColorMode_Color = 27100
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomRight = 27200
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomLeft = 27300
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomCenter = 27400
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomOutside = 27500
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomInside = 27600
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopRight = 27700
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopLeft = 27800
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopCenter = 27900
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopOutside = 28000
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopInside = 28100
    bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_HidePageNumbers = 28200
    bsPPUI_FormatOptionsDialog_fpcPageNumbers_ButtonToolTipTextDefault = 28300
    bsPPUI_FormatOptionsDialog_fpcPageNumbers_DrawSample_Bold = 28400
    bsPPUI_FormatOptionsDialog_fpcPageNumbers_DrawSample_Italic = 28500
    bsPPUI_FormatOptionsDialog_cboGridPosition_Centered = 28600
    bsPPUI_FormatOptionsDialog_cboGridPosition_Left = 28700
    bsPPUI_FormatOptionsDialog_cboGridPosition_Right = 28800
    bsPPUI_FormatOptionsDialog_cboGridPosition_Stretch = 28900
    bsPPUI_FormatOptionsDialog_cboGridPosition_EnlargeLastColumn = 29000
    bsPPUI_FormatOptionsDialog_cboGridPosition_ToolTipText = 29100
    bsPPUI_FormatOptionsDialog_lblStyle_Caption = 29200
    bsPPUI_FormatOptionsDialog_cboStyle_List_Style = 29300
    bsPPUI_FormatOptionsDialog_cboStyle_List_CustomStyle = 29400
    bsPPUI_FormatOptionsDialog_cboStyle_List_Customize = 29500
    bsPPUI_FormatOptionsDialog_cmdDeleteCustomStyle_ToolTipText = 29600
    bsPPUI_FormatOptionsDialog_lblLineThickness_Caption = 29700
    bsPPUI_FormatOptionsDialog_txtLineThickness_ToolTipText = 29800
    bsPPUI_FormatOptionsDialog_ValidateLineThickness_Message = 29900
    bsPPUI_FormatOptionsDialog_chkDrawHeaderBackground_Caption = 30000
    bsPPUI_FormatOptionsDialog_chkDrawFixedColsBackground_Caption = 30100
    bsPPUI_FormatOptionsDialog_cmdFixedSectionsBackgroundColor_ToolTipText = 30200
    bsPPUI_FormatOptionsDialog_chkDrawOtherBackgrounds_Caption = 30300
    bsPPUI_FormatOptionsDialog_chkDrawOuterBorder_Caption = 30400
    bsPPUI_FormatOptionsDialog_chkDrawHeaderBorder_Caption = 30500
    bsPPUI_FormatOptionsDialog_chkDrawColumnsHeadersLines_Caption = 30600
    bsPPUI_FormatOptionsDialog_chkDrawColumnsDataLines_Caption = 30700
    bsPPUI_FormatOptionsDialog_chkDrawRowLines_Caption = 30800
    bsPPUI_FormatOptionsDialog_chkDrawHeaderSeparatorLine_Caption = 30900
    bsPPUI_FormatOptionsDialog_txtHeaderSeparatorLineThickness_ToolTipText = 31000
    bsPPUI_FormatOptionsDialog_VariousChangeColorCommandButtons_ToolTipText = 31100
    bsPPUI_FormatOptionsDialog_ValidateHeaderSeparatorLineThickness_Message = 31200
    bsPPUI_FormatOptionsDialog_lblSample_Caption = 31300
    bsPPUI_FormatOptionsDialog_DrawSample_Column = 31400
    bsPPUI_FormatOptionsDialog_DrawSample_Element = 31500
    bsPPUI_FormatOptionsDialog_DrawSample_Data = 31600
    
    ' PageNumbersOptions dialog
    bsPPUI_PageNumbersOptionsDialog_Caption = 34000

End Enum

Public Sub BSPrinterGetLocalizedText(ByVal LanguageID As Long, ByVal SubLanguageID As Long, ByVal TextID As Long, Text As String)
    
    If LanguageID = bsLang_FINNISH Then
        
        ' You can use the tool at the following URL to find the correct captions:
        ' Microsoft teminology search: https://www.microsoft.com/en-us/language/search
        
        ' Note: This Finnish language translation is provided as an example of how a new translation should be handled
        ' and some items may not be accurate enough to be used
        
        ' For locale languages that do not have built-in support and are not handled here, English texts will be used
        
        Select Case TextID
            Case bsPPUI_General_CloseButton_Caption ' English: "Close"
                Text = "Kiinni"
            Case bsPPUI_General_OKButton_Caption ' English: "OK"
                Text = "OK"
            Case bsPPUI_General_CancelButton_Caption ' English: "Cancel"
                Text = "Peruuttaa"
            Case bsPPUI_General_Unnamed_FileName  ' English: "Unnamed"
                Text = "Nime�m�t�n"
            Case bsPPUI_General_PageNumbersFormatStrings_Count ' the number of items (listed following below)
                Text = "21"
                ' for some below, In MS: "Page {#} of {##}" or "Page X of Y"
            Case bsPPUI_General_PageNumbersFormatString_Item + 0 ' English: "{#}"
                Text = "{#}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 1 ' English: "-{#}-"
                Text = "-{#}-"
            Case bsPPUI_General_PageNumbersFormatString_Item + 2 ' English: "{#} / {##}"
                Text = "{#} / {##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 3 ' English: "{#}/{##}"
                Text = "{#}/{##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 4 ' English: "{#} of {##}"
                Text = "{#} {##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 5 ' English: "{r}"
                Text = "{r}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 6 ' English: "{R}"
                Text = "{R}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 7 ' English: "{a}"
                Text = "{a}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 8 ' English: "{A}"
                Text = "{A}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 9 ' English: "pg. {#}"
                Text = "P. {#}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 10 ' English: "pg. {#} / {##}"
                Text = "P. {#} / {##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 11 ' English: "pg. {#}/{##}"
                Text = "P. {#}/{##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 12 ' English: "pg. {#} of {##}"
                Text = "P. {#} {##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 13 ' English: "Page {#}"
                Text = "Sivu {#}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 14 ' English: Page {#} / {##}"
                Text = "Sivu {#} / {##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 15 ' English: "Page {#}/{##}"
                Text = "Sivu {#}/{##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 16 ' English: "Page {#} of {##}"
                Text = "Sivu {#} {##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 17 ' English: "page {#}"
                Text = "sivu {#}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 18 ' English: "page {#} / {##}"
                Text = "sivu {#} / {##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 19 ' English: "page {#}/{##}"
                Text = "sivu {#}/{##}"
            Case bsPPUI_General_PageNumbersFormatString_Item + 20 ' English: "page {#} of {##}"
                Text = "sivu {#} {##}"
            Case bsPPUI_General_PrintDocumentTooLongWarning_PageText ' English: "Document too long to print complete, done to the page {####}."
                Text = "Asiakirja on liian pitk� tulostamiseen valmis, tehty sivulle {####}."
            Case bsPPUI_General_PrintDocumentTooLongWarning_MsgBoxWarning ' English: "Document too long, will not be printed completely."
                Text = "Asiakirja liian pitk�, sit� ei tulosteta kokonaan."
            Case bsPPUI_General_PrinterNotAvailable1 ' English: "The printer 'PRINTER_NAME_DO_NOT_TRANSLATE_OR_MODIFY_THIS' is not available at this time, would you like to print in the default printer?"
                Text = "Tulostin 'PRINTER_NAME_DO_NOT_TRANSLATE_OR_MODIFY_THIS' ei ole t�ll� hetkell� k�ytett�viss�. Haluatko tulostaa oletustulostimella?"
            Case bsPPUI_General_PrinterNotAvailable2 ' English: "The printer 'PRINTER_NAME_DO_NOT_TRANSLATE_OR_MODIFY_THIS' is not available at this time, cannot print."
                Text = "Tulostin 'PRINTER_NAME_DO_NOT_TRANSLATE_OR_MODIFY_THIS' ei ole t�ll� hetkell� k�ytett�viss�, eik� sit� voi tulostaa."
            Case bsPPUI_General_PageNumbers_Dont_Exists_Message ' English: "The specified page number(s) do not exist in the document."
                Text = "M��ritettyj� sivunumeroita ei ole olemassa asiakirjassa."
            Case bsPPUI_General_SaveToFile_PrinterNotInstalled ' English: "The 'PRINTER_NAME_DO_NOT_TRANSLATE_OR_MODIFY_THIS' printer driver is not installed on this computer. Cannot save the file."
                Text = "'PRINTER_NAME_DO_NOT_TRANSLATE_OR_MODIFY_THIS' -tulostinohjainta ei ole asennettu t�h�n tietokoneeseen. Tiedostoa ei voi tallentaa."
            Case bsPPUI_General_GridReportStyleNames_Basic ' English: "Basic"
                Text = "Perus"
            Case bsPPUI_General_GridReportStyleNames_Basic_Gray ' English: "Basic Gray"
                Text = "Perus Harmaa"
            Case bsPPUI_General_GridReportStyleNames_Basic_Red ' English: "Basic Red"
                Text = "Perus Punainen"
            Case bsPPUI_General_GridReportStyleNames_Basic_Green ' English: "Basic Green"
                Text = "Perus Vihre�"
            Case bsPPUI_General_GridReportStyleNames_Basic_Yellow ' English: "Basic Yellow"
                Text = "Perus Keltainen"
            Case bsPPUI_General_GridReportStyleNames_Modern ' English: "Modern"
                Text = "Moderni"
            Case bsPPUI_General_GridReportStyleNames_Modern_Gray ' English: "Modern Gray"
                Text = "Moderni Harmaa"
            Case bsPPUI_General_GridReportStyleNames_Modern_Red ' English: "Modern Red"
                Text = "Moderni Punainen"
            Case bsPPUI_General_GridReportStyleNames_Modern_Green ' English: "Modern Green"
                Text = "Moderni Vihre�"
            Case bsPPUI_General_GridReportStyleNames_Modern_Yellow ' English: "Modern Yellow"
                Text = "Moderni Keltainen"
            Case bsPPUI_General_GridReportStyleNames_Grid ' English: "Grid"
                Text = "Ruudukko"
            Case bsPPUI_General_GridReportStyleNames_Grid_Gray ' English: "Grid Gray"
                Text = "Ruudukko Harmaa"
            Case bsPPUI_General_GridReportStyleNames_Grid_Red ' English: "Grid Red"
                Text = "Ruudukko Punainen"
            Case bsPPUI_General_GridReportStyleNames_Grid_Green ' English: "Grid Green"
                Text = "Ruudukko Vihre�"
            Case bsPPUI_General_GridReportStyleNames_Grid_Yellow ' English: "Grid Yellow"
                Text = "Ruudukko Keltainen"
            Case bsPPUI_General_GridReportStyleNames_Closed ' English: "Closed"
                Text = "Suljettu"
            Case bsPPUI_General_GridReportStyleNames_Closed_Gray ' English: "Closed Gray"
                Text = "Suljettu Harmaa"
            Case bsPPUI_General_GridReportStyleNames_Closed_Red ' English: "Closed Red"
                Text = "Suljettu Punainen"
            Case bsPPUI_General_GridReportStyleNames_Closed_Green ' English: "Closed Green"
                Text = "Suljettu Vihre�"
            Case bsPPUI_General_GridReportStyleNames_Closed_Yellow ' English: "Closed Yellow"
                Text = "Suljettu Keltainen"
            Case bsPPUI_General_GridReportStyleNames_Horizontal ' English: "Horizontal"
                Text = "Vaakasuora"
            Case bsPPUI_General_GridReportStyleNames_Horizontal_Gray ' English: "Horizontal Gray"
                Text = "Vaakasuora Harmaa"
            Case bsPPUI_General_GridReportStyleNames_Horizontal_Red ' English: "Horizontal Red"
                Text = "Vaakasuora Punainen"
            Case bsPPUI_General_GridReportStyleNames_Horizontal_Green ' English: "Horizontal Green"
                Text = "Vaakasuora Vihre�"
            Case bsPPUI_General_GridReportStyleNames_Horizontal_Yellow ' English: "Horizontal Yellow"
                Text = "Vaakasuora Keltainen"
            Case bsPPUI_General_GridReportStyleNames_Free ' English: "Free"
                Text = "Vapaa"
            Case bsPPUI_General_GridReportStyleNames_Free_Gray ' English: "Free Gray"
                Text = "Vapaa Harmaa"
            Case bsPPUI_General_GridReportStyleNames_Free_Red ' English: "Free Red"
                Text = "Vapaa Punainen"
            Case bsPPUI_General_GridReportStyleNames_Free_Green ' English: "Free Green"
                Text = "Vapaa Vihre�"
            Case bsPPUI_General_GridReportStyleNames_Free_Yellow ' English: "Free Yellow"
                Text = "Vapaa Keltainen"
            Case bsPPUI_PreviewDialog_Caption ' English: "Print preview"
                Text = "Tulostuksen esikatselu"
            Case bsPPUI_PreviewDialog_mnuView2p_Caption ' English: "View 2 pages"
                Text = "N�yt� 2 sivua"
            Case bsPPUI_PreviewDialog_mnuView3p_Caption ' English: "View 3 pages"
                Text = "N�yt� 3 sivua"
            Case bsPPUI_PreviewDialog_mnuView6p_Caption ' English: "View 6 pages"
                Text = "N�yt� 6 sivua"
            Case bsPPUI_PreviewDialog_mnuView12p_Caption ' English: "View 12 pages"
                Text = "N�yt� 12 sivua"
            Case bsPPUI_PreviewDialog_mnuTopIconsAuto_Caption ' English: "Automatic icon size"
                Text = "Automaattinen kuvakkeen koko"
            Case bsPPUI_PreviewDialog_mnuTopIconsSmall_Caption ' English: "Small icons"
                Text = "Pienet kuvakkeet"
            Case bsPPUI_PreviewDialog_mnuTopIconsMedium_Caption ' English: "Medium icons"
                Text = "Keskikokoiset kuvakkeet"
            Case bsPPUI_PreviewDialog_mnuTopIconsLarge_Caption ' English: "Large icons"
                Text = "Suuret kuvakkeet"
            Case bsPPUI_PreviewDialog_Icons_Size_Small ' English: "small"
                Text = "pieni"
            Case bsPPUI_PreviewDialog_Icons_Size_Medium ' English: "medium"
                Text = "keskikokoinen"
            Case bsPPUI_PreviewDialog_Icons_Size_large ' English: "large"
                Text = "suuri"
            Case bsPPUI_PreviewDialog_mnuTopShowBottomToolbar_Caption ' English: "Show bottom bar"
                Text = "N�yt� alapalkki"
            Case bsPPUI_PreviewDialog_mnuTopShowMargins_Caption ' English: "Show margins"
                Text = "N�yt� marginaalit"
            Case bsPPUI_PreviewDialog_CurrentlySelected ' English: "selected"
                Text = "valittu"
            Case bsPPUI_PreviewDialog_CurrentlyShown ' English: "currently shown"
                Text = "actualmente visible"
            Case bsPPUI_PreviewDialog_lblPageOrientation_Caption ' English: "Page orientation:"
                Text = "Sivun suunta:"
            Case bsPPUI_PreviewDialog_lblView_Caption ' English: "View:"
                Text = "N�kym�:"
            Case bsPPUI_PreviewDialog_lblScale_Caption ' English: "Scale:"
                Text = "Skaalata:"
            Case bsPPUI_PreviewDialog_CurrentPage_Singular_Caption ' English: "Page: {#} {##}"
                Text = "Sivu: {#} {##}"
            Case bsPPUI_PreviewDialog_CurrentPage_Plural_Caption ' English: "Pages: {#} {##}"
                Text = "Sivut: {#} {##}"
            Case bsPPUI_PreviewDialog_PreparingDoc_Caption_LoadingPreview ' English: "Loading preview..."
                Text = "Ladataan esikatselua..."
            Case bsPPUI_PreviewDialog_PreparingDoc_Caption_PreparingDocument ' English: "Preparing document..."
                Text = "Valmistellaan asiakirjaa..."
            Case bsPPUI_PreviewDialog_cmdPrintInDefaultPrinter_Caption ' English: "Print to {Printer_Name}"
                Text = "Tulosta kohteeseen {Printer_Name}"
            Case bsPPUI_PreviewDialog_cmdClose_Caption ' English: "Close print preview"
                Text = "Sulje esikatselu"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_Print ' English: "Print"
                Text = "Tulosta"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_PageSetup ' English: "Page setup"
                Text = "Sivun asetukset"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_PageNumbersOptions ' English: "Page numbers options"
                Text = "Sivunumeroiden asetukset"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_Format ' English: "Format"
                Text = "Muoto"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_OrientationPortrait ' English: "Portrait orientation"
                Text = "Pystysuunta"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_OrientationLandscape ' English: "Landscape orientation"
                Text = "Vaakasuunta"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_OrientationCantBeChanged ' English: "The page orientation cannot be changed"
                Text = "Sivun suuntaa ei voida muuttaa"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ViewNormalSize ' English: "View normal page size"
                Text = "N�yt� normaali sivukoko"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ViewFullWidth ' English: "View full width"
                Text = "N�yt� koko leveys"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ViewFullHeight ' English: "View full height"
                Text = "N�yt� koko korkeus"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ViewMultiplePages ' English: "Show multiple pages"
                Text = "N�yt� useita sivuja"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_DecreaseScale ' English: "Decrease fonts and elements size"
                Text = "Pienenn� fonttien ja elementtien kokoa"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_IncreaseScale ' English: "Increase fonts and elements size"
                Text = "Suurenna fonttien ja elementtien kokoa"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_ShowMenu ' English: "Open menu"
                Text = "Avaa valikko"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_FirstPage ' English: "First page"
                Text = "Ensimm�inen sivu"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_PreviousPage_Singular ' English: "Previous page"
                Text = "Edellinen sivu"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_PreviousPage_Plural ' English: "Previous pages"
                Text = "Edelliset sivut"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_NextPage_Singular ' English: "Next page"
                Text = "Seuraava sivu"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_NextPage_Plural ' English: "Next pages"
                Text = "Seuraavat sivut"
            Case bsPPUI_PreviewDialog_ToolTipText_ToolbarButton_LastPage ' English: "Last page"
                Text = "Viimeinen sivu"
            Case bsPPUI_PreviewDialog_NonPrintableAreaText ' English: "Nonprinting region"
                Text = "Ei-tulostettava alue"
            Case bsPPUI_PreviewDialog_Inches_Abbreviation ' English: """
                Text = """"
            Case bsPPUI_PreviewDialog_Millimeters_Abbreviation ' English: "mm"
                Text = "mm"
            Case bsPPUI_ProgressWindow_lblMessage_Caption_Start_PrintPreview ' English: "Loading preview"
                Text = "Ladataan esikatselua"
            Case bsPPUI_ProgressWindow_lblMessage_Caption_Progress_PrintPreview ' English: "Loading preview, page {#}"
                Text = "Ladataan esikatselua, sivu {#}"
            Case bsPPUI_ProgressWindow_lblMessage_Caption_Start_General ' English: "Generating document"
                Text = "Luodaan asiakirja"
            Case bsPPUI_ProgressWindow_lblMessage_Caption_Progress_General ' English: "Generating document, page {#}"
                Text = "Luodaan asiakirja, sivu {#}"
            Case bsPPUI_ProgressWindow_MsgBox_Cancel_Preview ' English: "Cancel the operation?"
                Text = "Peruuta toiminto?"
            Case bsPPUI_FormatOptionsDialog_Caption ' English: "Print format"
                Text = "Tulostusmuoto"
            Case bsPPUI_FormatOptionsDialog_TabCaption_1 ' English: "Options"
                Text = "Asetukset"
            Case bsPPUI_FormatOptionsDialog_TabCaption_2 ' English: "Style"
                Text = "Tyyli"
            Case bsPPUI_FormatOptionsDialog_lblScale_Caption ' English: "Scale:"
                Text = "Skaalata:"
            Case bsPPUI_FormatOptionsDialog_lblColorMode_Caption ' English: "Color mode:"
                Text = "V�ritila:"
            Case bsPPUI_FormatOptionsDialog_lblPageNumbersPosition_Caption ' English: "Page numbers position:"
                Text = "Sivunumeroiden sijainti:"
            Case bsPPUI_FormatOptionsDialog_lblPageNumberFormat_Caption ' English: "Page number format:"
                Text = "Sivunumeron muoto:"
            Case bsPPUI_FormatOptionsDialog_lblPageNumbersFont_Caption ' English: "Page numbers font:"
                Text = "Sivunumerot fontti:"
            Case bsPPUI_FormatOptionsDialog_lblGridPosition_Caption ' English: "Data grid position:"
                Text = "Tietoruudukon sijainti:"
            Case bsPPUI_FormatOptionsDialog_cboColorMode_PrinterDefault ' English: "Printer default"
                Text = "Tulostimen oletus"
            Case bsPPUI_FormatOptionsDialog_cboColorMode_GrayScale ' English: "Grayscale"
                Text = "Harmaas�vy"
            Case bsPPUI_FormatOptionsDialog_cboColorMode_Color ' English: "Color"
                Text = "V�ri"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomRight ' English: "Bottom right"
                Text = "Oikea alareuna"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomLeft ' English: "Bottom left"
                Text = "Vasen alareuna"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomCenter ' English: "Bottom center"
                Text = "Alhaalla keskell�"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomOutside ' English: "Bottom outside"
                Text = "Alhaalla ulkopuolella"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_BottomInside ' English: "Bottom inside"
                Text = "Alhaalla sis�ll�"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopRight ' English: "Top right"
                Text = "Oikea yl�kulma"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopLeft ' English: "Top left"
                Text = "Vasen yl�kulma"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopCenter ' English: "Top center"
                Text = "Ylh��ll� keskell�"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopOutside ' English: "Top outside"
                Text = "Ylh��ll� ulkopuolella"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_TopInside ' English: "Top inside"
                Text = "Ylh��ll� sis�ll�"
            Case bsPPUI_FormatOptionsDialog_cboPageNumbersPosition_HidePageNumbers ' English: "Hide page numbers"
                Text = "Piilota sivunumerot"
            Case bsPPUI_FormatOptionsDialog_fpcPageNumbers_ButtonToolTipTextDefault ' English: "Choose font"
                Text = "Oma fontti"
            Case bsPPUI_FormatOptionsDialog_fpcPageNumbers_DrawSample_Bold ' English: "bold"
                Text = "lihavointi"
            Case bsPPUI_FormatOptionsDialog_fpcPageNumbers_DrawSample_Italic ' English: "italic"
                Text = "kursivoitu"
            Case bsPPUI_FormatOptionsDialog_cboGridPosition_Centered ' English: "Centered"
                Text = "Keskitetty"
            Case bsPPUI_FormatOptionsDialog_cboGridPosition_Left ' English: "Left"
                Text = "Vasen"
            Case bsPPUI_FormatOptionsDialog_cboGridPosition_Right ' English: "Right"
                Text = "Oikea"
            Case bsPPUI_FormatOptionsDialog_cboGridPosition_Stretch ' English: "Stretch"
                Text = "Venyt�"
            Case bsPPUI_FormatOptionsDialog_cboGridPosition_EnlargeLastColumn ' English: "Enlarge the last column"
                Text = "Suurenna viimeinen sarake"
            Case bsPPUI_FormatOptionsDialog_cboGridPosition_ToolTipText ' English: "It only has effect when the data grid is narrower than the page"
                Text = "Sill� on vaikutusta vain, kun tietokentt� on kapeampi kuin sivu"
            Case bsPPUI_FormatOptionsDialog_lblStyle_Caption ' English: "Style:"
                Text = "Tyyli:"
            Case bsPPUI_FormatOptionsDialog_cboStyle_List_Style ' English: "Style"
                Text = "Tyyli"
            Case bsPPUI_FormatOptionsDialog_cboStyle_List_CustomStyle ' English: "Custom style"
                Text = "Mukautettu tyyli"
            Case bsPPUI_FormatOptionsDialog_cboStyle_List_Customize ' English: "Customize"
                Text = "Mukauta"
            Case bsPPUI_FormatOptionsDialog_cmdDeleteCustomStyle_ToolTipText ' English: "Delete style"
                Text = "Poista tyyli"
            Case bsPPUI_FormatOptionsDialog_lblLineThickness_Caption ' English: "Line thickness:"
                Text = "Viivan paksuus:"
            Case bsPPUI_FormatOptionsDialog_txtLineThickness_ToolTipText ' English: "Change line thickness (general)"
                Text = "Vaihda viivan paksuus (yleinen)"
            Case bsPPUI_FormatOptionsDialog_ValidateLineThickness_Message ' English: "The line thickness value must be between 1 and 80"
                Text = "Viivan paksuuden arvon on oltava v�lill� 1 - 80"
            Case bsPPUI_FormatOptionsDialog_chkDrawHeaderBackground_Caption ' English: "Header background"
                Text = "Yl�tunnisteen tausta"
            Case bsPPUI_FormatOptionsDialog_chkDrawFixedColsBackground_Caption ' English: "Fixed columns Backg."
                Text = "Kiinteiden sarakkeiden tausta"
            Case bsPPUI_FormatOptionsDialog_cmdFixedSectionsBackgroundColor_ToolTipText ' English: "Change background color of header (and / or fixed columns)"
                Text = "Muuta otsikon (ja / tai kiinteiden sarakkeiden) taustav�ri�"
            Case bsPPUI_FormatOptionsDialog_chkDrawOtherBackgrounds_Caption ' English: "Other background colors"
                Text = "Muut taustav�rit"
            Case bsPPUI_FormatOptionsDialog_chkDrawOuterBorder_Caption ' English: "Outer border"
                Text = "Piirr� ulkoreuna"
            Case bsPPUI_FormatOptionsDialog_chkDrawHeaderBorder_Caption ' English: "Header border"
                Text = "Yl�tunnistereunus"
            Case bsPPUI_FormatOptionsDialog_chkDrawColumnsHeadersLines_Caption ' English: "Column headers lines"
                Text = "Sarakeotsikkorivit"
            Case bsPPUI_FormatOptionsDialog_chkDrawColumnsDataLines_Caption ' English: "Columns data lines"
                Text = "Sarakkeiden tietorivit"
            Case bsPPUI_FormatOptionsDialog_chkDrawRowLines_Caption ' English: "Row lines"
                Text = "Rivirivit"
            Case bsPPUI_FormatOptionsDialog_chkDrawHeaderSeparatorLine_Caption ' English: "Header separator:"
                Text = "Otsikon erotin:"
            Case bsPPUI_FormatOptionsDialog_txtHeaderSeparatorLineThickness_ToolTipText ' English: "Header separator line thickness"
                Text = "Otsikon erottimen viivan paksuus"
            Case bsPPUI_FormatOptionsDialog_VariousChangeColorCommandButtons_ToolTipText ' English: "Change color"
                Text = "Muuta v�ri"
            Case bsPPUI_FormatOptionsDialog_ValidateHeaderSeparatorLineThickness_Message ' English: "The line thickness value must be between 1 and 80"
                Text = "Viivan paksuuden arvon on oltava v�lill� 1 - 80"
            Case bsPPUI_FormatOptionsDialog_lblSample_Caption ' English: "Sample:"
                Text = "N�yte:"
            Case bsPPUI_FormatOptionsDialog_DrawSample_Column ' English: "Column"
                Text = "Sarake"
            Case bsPPUI_FormatOptionsDialog_DrawSample_Element ' English: "Element"
                Text = "Elementti"
            Case bsPPUI_FormatOptionsDialog_DrawSample_Data ' English: "Data"
                Text = "Tietoer�"
            Case bsPPUI_PageNumbersOptionsDialog_Caption ' English: "Page numbers options"
                Text = "Sivunumeroiden asetukset"
        End Select
    End If
End Sub

