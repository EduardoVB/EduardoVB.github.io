Attribute VB_Name = "mMain"
Option Explicit

' Printer replacement code:
Public Property Get Printer() As Printer
    Set Printer = PrinterReplacement
End Property

Public Property Set Printer(nPrinter As Printer)
    Set PrinterReplacement = nPrinter
End Property

' Sub Main, where the program starts
Public Sub Main()
    Dim c1 As Class1
    
    Set c1 = New Class1
    c1.PrintReport
End Sub

