VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Save PDF button"
   ClientHeight    =   6384
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   6756
   LinkTopic       =   "Form1"
   ScaleHeight     =   6384
   ScaleWidth      =   6756
   Begin VB.PictureBox Picture1 
      Height          =   492
      Left            =   5064
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   444
      ScaleWidth      =   444
      TabIndex        =   2
      Top             =   5280
      Visible         =   0   'False
      Width           =   492
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   492
      Left            =   312
      TabIndex        =   0
      Top             =   384
      Width           =   1908
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   2736
      Top             =   336
      _ExtentX        =   953
      _ExtentY        =   953
      ToolbarButtonPicture3_0=   "Form1.frx":18652
      ToolbarButtonPicture3_1=   "Form1.frx":18B54
      ToolbarButtonPicture3_2=   "Form1.frx":19266
      ToolbarButtonPicture3_3=   "Form1.frx":19D80
      ToolbarButtonPicture3_4=   "Form1.frx":1AD02
   End
   Begin VB.Label Label4 
      Caption         =   $"Form1.frx":1C4A4
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   756
      Left            =   372
      TabIndex        =   6
      Top             =   4752
      Width           =   6180
   End
   Begin VB.Label Label3 
      Caption         =   $"Form1.frx":1C564
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   732
      Left            =   372
      TabIndex        =   5
      Top             =   3960
      Width           =   6180
   End
   Begin VB.Label Label5 
      Caption         =   $"Form1.frx":1C5FB
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   756
      Left            =   372
      TabIndex        =   4
      Top             =   3144
      Width           =   6180
   End
   Begin VB.Label Label2 
      Caption         =   $"Form1.frx":1C6DE
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   756
      Left            =   372
      TabIndex        =   3
      Top             =   2244
      Width           =   6180
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":1C7AF
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   756
      Left            =   372
      TabIndex        =   1
      Top             =   1404
      Width           =   6180
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    PrintPreview1.ShowPreview
End Sub

Private Sub Form_Load()
    PrintPreview1.AuxiliaryButtonVisible = PrintPreview1.PrinterExists("Microsoft Print to PDF")
    PrintPreview1.AuxiliaryButtonToolTipText = "Save as PDF"
End Sub

Private Sub PrintPreview1_AuxiliaryButtonClick(UpdateReport As Boolean)
    PrintPreview1.ShowSaveToFile "Microsoft Print to PDF", "*.pdf"
    UpdateReport = False ' we don't need to update the report in the Print preview window after this action (the default value of UpdateReport parameter is True)
End Sub

' code taken from Sample 2, just to print something
Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim Str As String
    
    ' Text positioning
    
    Printer.FontSize = 18
    Printer.FontBold = True
    
    'The following code centers the title
    Str = "CENTERED TITLE"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.Print Str
    Printer.Print vbCrLf ' line feed to have some space with the next printing
    
    Printer.FontSize = 12
    Printer.FontBold = False
    
    ' Text positioned at left
    Printer.Print "Left positioned";
    
    ' Text positioned at right
    Str = "Right positioned"
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text positioned at bottom left
    Str = "Bottom left"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.Print Str
    
    ' Text positioned at bottom right
    Str = "Bottom right"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text at center of page
    Str = "Page centered"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.CurrentY = (Printer.ScaleHeight - Printer.TextHeight(Str)) / 2
    Printer.Print Str
    
    
    ' Page 2
    ' Image positioning
    Printer.NewPage
    
    ' Left top
    Printer.PaintPicture Picture1.Picture, 0, 0
    
    ' Right top
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), 0

    ' Left Bottom
    Printer.PaintPicture Picture1.Picture, 0, Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Right Bottom
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Centered in page
    Printer.PaintPicture Picture1.Picture, (Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode)) / 2, (Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)) / 2

    
    ' Page 3
    ' Some elements of always the same size, no matter the scale the user sets
    Printer.NewPage
    Printer.Print "Some elements keep their size"
    Printer.Print "(regardless of scale)"

    Printer.FontSize = 24 * 100 / PrintPreview1.ScalePercent
    
    Printer.Print
    Printer.Print
    Printer.Print ; "Scale independent text size"
    
    Printer.FontSize = 12 ' restore the font size to old value of 12
    Printer.Print "Variable size text"
    
    ' Fixed size image
    Dim Proportion As Single
    
    Printer.Print
    Printer.Print
    Printer.Print "Scale independent image size:"
    
    ' Image width of always half page width (the margins are not taken into account) and horizontally centered
    Proportion = Printer.ScaleWidth / 2 / Picture1.Picture.Width
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth / 4, Printer.CurrentY + 500, Picture1.Picture.Width * Proportion, Picture1.Picture.Height * Proportion
    
    ' Page 4
    Printer.NewPage
    ' All page os fixed size, regardless of the sacle the user has set
    ' Notes:
    ' This technique can be used for full pages, because it changes Printer.Zoom, and it can be changed after the pages is created
    ' Printer.Zoom needs to be restored in the next page
    
    Printer.Zoom = 100 / PrintPreview1.ScalePercent * 100
    Printer.Print "All page the same size, no matter scale"
    Printer.PaintPicture Picture1.Picture, 0, 500
    Printer.CurrentY = 2700
    Printer.Print "Boat in the middle of the sea"
    
    ' Page 5
    ' Drawing
    Printer.NewPage
    Printer.Zoom = 100
    
    Str = "Drawing" ' title
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.FontUnderline = True
    Printer.Print Str & vbCrLf
    Printer.FontUnderline = False
    
    ' Circle centered horizontally
    Printer.DrawWidth = 10
    Printer.Circle (Printer.ScaleWidth / 2, 2000), 1500, vbRed
    
    ' Rectangle at left
    Printer.Line (0, 4000)-(3000, 6000), vbBlue, B
    
    ' Filled rectangle at right
    Printer.Line (Printer.ScaleWidth - 3000, 4000)-(Printer.ScaleWidth, 6000), vbGreen, BF
    
    ' Triangle drawn with lines, horizontally centered at bottom
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
End Sub

