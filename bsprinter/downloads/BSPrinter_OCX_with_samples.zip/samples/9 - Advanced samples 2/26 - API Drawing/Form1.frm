VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "API Drawing"
   ClientHeight    =   2496
   ClientLeft      =   2772
   ClientTop       =   2256
   ClientWidth     =   4944
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   2496
   ScaleWidth      =   4944
   Begin VB.PictureBox Picture1 
      Height          =   492
      Left            =   3960
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   444
      ScaleWidth      =   444
      TabIndex        =   2
      Top             =   192
      Visible         =   0   'False
      Width           =   492
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   2928
      Top             =   672
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview"
      Height          =   468
      Left            =   672
      TabIndex        =   0
      Top             =   696
      Width           =   1764
   End
   Begin VB.Label Label1 
      Caption         =   "Note: Do not cache Printer.hDC into a variable because it changes on every page."
      Height          =   732
      Left            =   288
      TabIndex        =   1
      Top             =   1584
      Width           =   4380
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

' declarations used on page 1
Private Type POINTAPI
    X       As Long
    Y       As Long
End Type

Private Declare Function Polygon Lib "gdi32" (ByVal hDC As Long, lpPoint As POINTAPI, ByVal nCount As Long) As Long

' declarations used on page 2
Private Declare Function BeginPath Lib "gdi32" (ByVal hDC As Long) As Long
Private Declare Function EndPath Lib "gdi32" (ByVal hDC As Long) As Long
Private Declare Function StrokeAndFillPath Lib "gdi32" (ByVal hDC As Long) As Long

' declarations used on page 3
Private Type xForm
  eM11 As Single
  eM12 As Single
  eM21 As Single
  eM22 As Single
  eDx As Single
  eDy As Single
End Type

Private Const GM_ADVANCED As Long = &H2

Private Declare Function SetWorldTransform Lib "gdi32" (ByVal hDC As Long, ByRef lpXform As xForm) As Long
Private Declare Function SetGraphicsMode Lib "gdi32" (ByVal hDC As Long, ByVal iMode As Long) As Long
Private Declare Function GetWorldTransform Lib "gdi32" (ByVal hDC As Long, ByRef lpXform As xForm) As Long

Private Sub Command1_Click()
    PrintPreview1.PageView = bsPVThreePages
    PrintPreview1.ShowPreview
End Sub

Public Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim Points() As POINTAPI
    Dim LeftMargin As Long
    Dim TopMargin As Long
    
    Printer.ScaleMode = vbPixels
    
    ' the following is the way to get the margins in pixels for working with the hDC (if you change Printer.Zoom, need to compute that also)
    LeftMargin = Printer.ScaleX(PrintPreview1.LeftMargin, PrintPreview1.MarginUnits, vbPixels) * 100 / PrintPreview1.ScalePercent
    TopMargin = Printer.ScaleY(PrintPreview1.TopMargin, PrintPreview1.MarginUnits, vbPixels) * 100 / PrintPreview1.ScalePercent
    
    ' page 1
    ' draw a closed figure with Polygon API
    Printer.Print "" ' need to print something to initialize the printer object
    Printer.ForeColor = &H808080 ' color of border: a gray
    Printer.DrawWidth = 20 ' thickness of the border: 20 pixels
    Printer.FillStyle = vbSolid
    Printer.FillColor = &HFFD0D0 ' background color: a light blue
    
    ' draw a 5 edges figure
    ReDim Points(5) ' 6 points for the vertices (0 to 5), repeating the first at the end to close the figure
    
    Points(0).X = 1000 + LeftMargin: Points(0).Y = 1000 + TopMargin
    Points(1).X = 2000 + LeftMargin: Points(1).Y = 1000 + TopMargin
    Points(2).X = 3000 + LeftMargin: Points(2).Y = 2000 + TopMargin
    Points(3).X = 2000 + LeftMargin: Points(3).Y = 3000 + TopMargin
    Points(4).X = 1000 + LeftMargin: Points(4).Y = 2000 + TopMargin
    Points(5).X = 1000 + LeftMargin: Points(5).Y = 1000 + TopMargin
    
    Polygon Printer.hDC, Points(0), 6
    
    Printer.ForeColor = vbBlack
    Printer.FontSize = 14
    Printer.CurrentY = 0
    PrintPreview1.PrintEx "API used: Polygon", , , , , Printer.ScaleHeight, bsAlignCenterBottom
    
    ' page 2
    ' draw text using paths APIs
    Printer.NewPage
    
    ' draw an outlined text
    BeginPath Printer.hDC
    Printer.FontSize = 50
    PrintPreview1.PrintEx "Outlined Text", , , , , , bsAlignCenterTop
    EndPath Printer.hDC
    
    Printer.DrawWidth = 15
    Printer.ForeColor = vbGreen
    Printer.FillColor = vbBlue
    Printer.FillStyle = vbSolid
    
    StrokeAndFillPath Printer.hDC
    
    Printer.ForeColor = vbBlack
    Printer.FontSize = 14
    Printer.CurrentY = 0
    PrintPreview1.PrintEx "API used: BeginPath, EndPath and StrokeAndFillPath", , , , , Printer.ScaleHeight, bsAlignCenterBottom
    
    ' page 3
    ' print a rotated text and image
    Printer.NewPage

    Const Pi = 3.141592654
    Dim Oldmatrix As xForm
    Dim NewMatrix As xForm
    Dim X As Single
    Dim OldMode As Long
    Dim Angle As Long
    Dim PosX As Long
    Dim PosY As Long
    Dim ImageWidth As Long
    Dim ImageHeight As Long
    Dim ImageScale As Single
    Dim Str1 As String
    
    ' variables about the image size and dimensions
    ImageWidth = Printer.ScaleX(Picture1.Picture.Width, vbHimetric, vbPixels)
    ImageHeight = Printer.ScaleY(Picture1.Picture.Height, vbHimetric, vbPixels)
    ImageScale = 2 'Printer.ScaleWidth * 0.7 / ImageWidth
    If (ImageHeight * ImageScale) > Printer.ScaleHeight * 0.4 Then
        ImageScale = Printer.ScaleHeight * 0.4 / ImageHeight
    End If
    ImageWidth = ImageWidth * ImageScale
    ImageHeight = ImageHeight * ImageScale
    PosX = Printer.ScaleWidth * 0.15
    PosY = PosX * 1.5
    
    ' angle of rotation, can be 0 to 360
    Angle = 45
    
    ' set the matrix of rotation needed for SetWorldTransform API
    X = CSng(180 - Angle) * (2 * Pi) / 360 - Pi
    With NewMatrix
        .eM11 = Cos(X)
        .eM12 = Sin(X)
        .eM21 = -Sin(X)
        .eM22 = Cos(X)
        .eDx = (PosX + LeftMargin + ImageWidth / 2) - Cos(X) * (PosX + LeftMargin + ImageWidth / 2) + Sin(X) * (PosY + TopMargin + ImageHeight / 2)
        .eDy = (PosY + TopMargin + ImageHeight / 2) - Cos(X) * (PosY + TopMargin + ImageHeight / 2) - Sin(X) * (PosX + LeftMargin + ImageWidth / 2)
    End With
    
    ' set the canvas (device context) rotated
    OldMode = SetGraphicsMode(Printer.hDC, GM_ADVANCED)
    Call GetWorldTransform(Printer.hDC, Oldmatrix)
    Call SetWorldTransform(Printer.hDC, NewMatrix)
    
    ' print text centered "horizontally" over the image
    Str1 = "Rotated text and image"
    Printer.CurrentX = PosX + ImageWidth / 2 - Printer.TextWidth(Str1) / 2
    Printer.Print Str1
    
    ' paint the image
    Printer.PaintPicture Picture1.Picture, PosX, PosY, ImageWidth, ImageHeight
    
    Call SetWorldTransform(Printer.hDC, Oldmatrix)
    OldMode = SetGraphicsMode(Printer.hDC, OldMode)
    ' End of rotation, we're now back to normal
    
    Printer.CurrentY = 0
    PrintPreview1.PrintEx "API used: SetGraphicsMode, GetWorldTransform and SetWorldTransform", , , , , Printer.ScaleHeight, bsAlignCenterBottom
    
End Sub
