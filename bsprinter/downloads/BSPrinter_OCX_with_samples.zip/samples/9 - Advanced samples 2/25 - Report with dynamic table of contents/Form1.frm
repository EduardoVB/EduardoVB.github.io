VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Table of Contents"
   ClientHeight    =   3360
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   5160
   LinkTopic       =   "Form1"
   ScaleHeight     =   3360
   ScaleWidth      =   5160
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview window"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   612
      Left            =   864
      TabIndex        =   0
      Top             =   768
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3264
      Top             =   744
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label2 
      Caption         =   "Watch the code."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   636
      Left            =   288
      TabIndex        =   2
      Top             =   2616
      Width           =   4572
   End
   Begin VB.Label Label1 
      Caption         =   "This sample demostrates how to write a report with a Table of Contents."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   636
      Left            =   288
      TabIndex        =   1
      Top             =   1848
      Width           =   4572
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

' data to print in the sample
Private mTexts() As String
Private mTitles() As String

Private mTOC_Items() As String ' TOC items (like titles)
Private mTOC_Pages() As Long ' page where are the above items printed
Private mUB As Long ' current dimension of the arrays
Private mTOPCurrentIndex As Long ' current index when adding elements to the TOC

Private Sub Command1_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

Private Sub Form_Load()
    Dim ff As Long
    Dim Str As String
    Dim Pos As Long
    Dim c As Long
    
    ' load sample text data
    ff = FreeFile
    Open App.Path & "\sample_data.txt" For Input Access Read As #ff
    Str = Input(LOF(ff), ff)
    Close #ff
    mTexts = Split(Str, vbCrLf & vbCrLf)
    ReDim mTitles(UBound(mTexts))
    For c = 0 To UBound(mTexts)
        Pos = InStr(mTexts(c), ".")
        mTitles(c) = Left$(mTexts(c), Pos - 1)
    Next c
    
End Sub

Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim c As Long
    Dim PagesAdded As Long
    Dim PosY As Long
    
    ' initialize array variables
    mUB = 100
    ReDim mTOC_Items(mUB)
    ReDim mTOC_Pages(mUB)
    mTOPCurrentIndex = 0
    
    ' First we print the topics, in this sample program, one per page
    Printer.Font.Size = 18
    
    For c = 0 To UBound(mTexts)
        If c > 0 Then Printer.NewPage
        Printer.FontBold = True
        PrintPreview1.PrintEx mTitles(c) ' Here we use PrintPreview1.PrintEx instead of Printer.Print because it handles text lines automatically
        Printer.FontBold = False
        Printer.Print
        PrintPreview1.PrintEx mTexts(c) ' same as comment above
        AddToTOC mTitles(c), Printer.Page   ' add item and page to arrays for later building the TOC
    Next c
    ReDim Preserve mTOC_Items(mTOPCurrentIndex)
    ReDim Preserve mTOC_Pages(mTOPCurrentIndex)
    
    ' the first page is a cover
    PrintPreview1.GoToPage 0
    Printer.NewPage
    Printer.FontSize = 55
    Printer.ForeColor = &H808080
    PrintPreview1.PrintEx "BSPrinter Sample:" & vbCrLf & "Table of Contents", , 0, 0, Printer.ScaleWidth, Printer.ScaleHeight, bsAlignCenterCenter
    Printer.ForeColor = vbBlack
    
    ' first TOC page
    Printer.NewPage
    Printer.FontUnderline = True
    Printer.FontSize = 24
    PrintPreview1.PrintEx "Table of Contents" & vbCrLf, , , , , , bsAlignCenterTop
    Printer.FontUnderline = False
    Printer.Print
    PosY = Printer.CurrentY
    
    ' how many page do we need to add for the TOC?
    Printer.FontSize = 12
    PagesAdded = 2 ' the cover + first TOC page already added
    For c = 1 To mTOPCurrentIndex
        If (Printer.TextHeight(mTOC_Items(c)) + Printer.CurrentY) > Printer.ScaleHeight Then
            Printer.NewPage ' add TOC page
            PagesAdded = PagesAdded + 1
        End If
        Printer.CurrentX = 0
        Printer.Print
    Next
    
    ' print the TOC items
    PrintPreview1.GoToPage 2
    Printer.CurrentY = PosY
    For c = 1 To mTOPCurrentIndex
        Printer.CurrentX = 0
        Printer.Print mTOC_Items(c);
        DrawDots Printer.CurrentX + 100, Printer.ScaleWidth - Printer.TextWidth(mTOC_Pages(c) + PagesAdded & "  ")
        Printer.Print mTOC_Pages(c) + PagesAdded
    Next
End Sub

' store in two arrays the info for the table of contents
Private Sub AddToTOC(Item As String, Page As Long)
    mTOPCurrentIndex = mTOPCurrentIndex + 1
    If mTOPCurrentIndex > mUB Then
        mUB = mUB + 100
        ReDim Preserve mTOC_Items(mUB)
        ReDim Preserve mTOC_Pages(mUB)
    End If
    mTOC_Items(mTOPCurrentIndex) = Item
    mTOC_Pages(mTOPCurrentIndex) = Page
End Sub

' draw dots between the item and the page number
Private Sub DrawDots(ByVal nLeft As Long, ByVal nRight As Long)
    Dim c As Long
    Dim iTh As Long
    Dim iCy As Long
    
    nLeft = Round(nLeft / 100) * 100
    nRight = Int(nRight / 100) * 100
    
    iCy = Printer.CurrentY
    Printer.DrawWidth = 10
    iTh = Printer.TextHeight("l") * 0.3
    For c = nLeft To nRight Step 100
        Printer.PSet (c, iCy + iTh * 2)
    Next
    Printer.CurrentY = iCy
End Sub

