VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Customize the User Interface look"
   ClientHeight    =   3708
   ClientLeft      =   1344
   ClientTop       =   1920
   ClientWidth     =   8280
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   3708
   ScaleWidth      =   8280
   Begin VB.ComboBox cboUIButtonStyle 
      Height          =   312
      Left            =   1824
      Style           =   2  'Dropdown List
      TabIndex        =   5
      Top             =   2184
      Width           =   3250
   End
   Begin VB.ComboBox cboUIFontName 
      Height          =   312
      Left            =   1824
      Sorted          =   -1  'True
      Style           =   2  'Dropdown List
      TabIndex        =   3
      Top             =   1512
      Width           =   3250
   End
   Begin VB.PictureBox Picture1 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   540
      Left            =   7536
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   492
      ScaleWidth      =   420
      TabIndex        =   1
      Top             =   3072
      Visible         =   0   'False
      Width           =   468
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview window"
      Height          =   612
      Left            =   864
      TabIndex        =   0
      Top             =   432
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   2568
      Top             =   456
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Caption         =   "UIButonStyle:"
      Height          =   372
      Left            =   360
      TabIndex        =   6
      Top             =   2208
      Width           =   1284
   End
   Begin VB.Label lblFontSample 
      Height          =   324
      Left            =   5220
      TabIndex        =   4
      Top             =   1512
      Width           =   3000
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Caption         =   "UIFontName:"
      Height          =   372
      Left            =   360
      TabIndex        =   2
      Top             =   1524
      Width           =   1284
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cboUIFontName_Click()
    PrintPreview1.UIFontName = cboUIFontName.Text
    Set lblFontSample.Font = New StdFont
    lblFontSample.Font.Name = cboUIFontName.Text
    lblFontSample.Caption = cboUIFontName.Text
End Sub

Private Sub cboUIButtonStyle_Click()
    PrintPreview1.UIButtonStyle = cboUIButtonStyle.ItemData(cboUIButtonStyle.ListIndex)
End Sub

Private Sub Command1_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

Private Sub Form_Load()
    Dim c As Long
    Dim CurrentUIFontName As String
    
    ' load options in comboboxes and select them with the current settings
    
    ' current font of UIFontName property
    CurrentUIFontName = PrintPreview1.UIFontName
    If CurrentUIFontName = "[Auto]" Then
        If ScreenFontExists("Segoe UI") Then
            CurrentUIFontName = "Segoe UI"
        ElseIf ScreenFontExists("Tahoma") Then
            CurrentUIFontName = "Tahoma"
        Else
            CurrentUIFontName = "Arial"
        End If
    End If
    
    ' load available fonts
    For c = 0 To Screen.FontCount - 1
        cboUIFontName.AddItem Screen.Fonts(c)
    Next c
    
    ' select current font
    For c = 0 To cboUIFontName.ListCount - 1
        If cboUIFontName.List(c) = CurrentUIFontName Then
            cboUIFontName.ListIndex = c
            Exit For
        End If
    Next c
    
    ' load all available button styles
    cboUIButtonStyle.AddItem bsButtonStyleWindowsStandard & " - bsButtonStyleWindowsStandard": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleWindowsStandard
    cboUIButtonStyle.AddItem bsButtonStyleShinyMetal & " - bsButtonStyleShinyMetal": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleShinyMetal
    cboUIButtonStyle.AddItem bsButtonStyleIlluminated & " - bsButtonStyleIlluminated": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleIlluminated
    cboUIButtonStyle.AddItem bsButtonStyle3DClassic & " - bsButtonStyle3DClassic": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyle3DClassic
    cboUIButtonStyle.AddItem bsButtonStyleSimple2D & " - bsButtonStyleSimple2D": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleSimple2D
    cboUIButtonStyle.AddItem bsButtonStyleSimileAero & " - bsButtonStyleSimileAero": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleSimileAero
    cboUIButtonStyle.AddItem bsButtonStyleLightsAndShadows & " - bsButtonStyleLightsAndShadows": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleLightsAndShadows
    cboUIButtonStyle.AddItem bsButtonStyleOrange & " - bsButtonStyleOrange": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleOrange
    cboUIButtonStyle.AddItem bsButtonStyleBluish & " - bsButtonStyleBluish": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleBluish
    cboUIButtonStyle.AddItem bsButtonStylePolished & "  - bsButtonStylePolished": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStylePolished
    cboUIButtonStyle.AddItem bsButtonStyleBlueMoon & " - bsButtonStyleBlueMoon": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleBlueMoon
    cboUIButtonStyle.AddItem bsButtonStyleWhiteBlue & " - bsButtonStyleWhiteBlue": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleWhiteBlue
    cboUIButtonStyle.AddItem bsButtonStyleWhiteBlueInverted & " - bsButtonStyleWhiteBlueInverted": cboUIButtonStyle.ItemData(cboUIButtonStyle.NewIndex) = bsButtonStyleWhiteBlueInverted
    
    ' select current button style
    For c = 0 To cboUIButtonStyle.ListCount - 1
        If cboUIButtonStyle.ItemData(c) = PrintPreview1.UIButtonStyle Then
            cboUIButtonStyle.ListIndex = c
            Exit For
        End If
    Next c
End Sub

Private Function ScreenFontExists(ByVal FontName As String) As Boolean
    Dim c As Long
    
    FontName = LCase$(FontName)
    For c = 0 To Screen.FontCount - 1
        If LCase$(Screen.Fonts(c)) = FontName Then
            ScreenFontExists = True
            Exit Function
        End If
    Next c
End Function

' code taken from Sample 2, just to print something
Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim Str As String
    
    ' Text positioning
    
    Printer.FontSize = 18
    Printer.FontBold = True
    
    'The following code centers the title
    Str = "CENTERED TITLE"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.Print Str
    Printer.Print vbCrLf ' line feed to have some space with the next printing
    
    Printer.FontSize = 12
    Printer.FontBold = False
    
    ' Text positioned at left
    Printer.Print "Left positioned";
    
    ' Text positioned at right
    Str = "Right positioned"
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text positioned at bottom left
    Str = "Bottom left"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.Print Str
    
    ' Text positioned at bottom right
    Str = "Bottom right"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text at center of page
    Str = "Page centered"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.CurrentY = (Printer.ScaleHeight - Printer.TextHeight(Str)) / 2
    Printer.Print Str
    
    
    ' Page 2
    ' Image positioning
    Printer.NewPage
    
    ' Left top
    Printer.PaintPicture Picture1.Picture, 0, 0
    
    ' Right top
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), 0

    ' Left Bottom
    Printer.PaintPicture Picture1.Picture, 0, Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Right Bottom
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Centered in page
    Printer.PaintPicture Picture1.Picture, (Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode)) / 2, (Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)) / 2

    
    ' Page 3
    ' Some elements of always the same size, no matter the scale the user sets
    Printer.NewPage
    Printer.Print "Some elements keep their size"
    Printer.Print "(regardless of scale)"

    Printer.FontSize = 24 * 100 / PrintPreview1.ScalePercent
    
    Printer.Print
    Printer.Print
    Printer.Print ; "Scale independent text size"
    
    Printer.FontSize = 12 ' restore the font size to old value of 12
    Printer.Print "Variable size text"
    
    ' Fixed size image
    Dim Proportion As Single
    
    Printer.Print
    Printer.Print
    Printer.Print "Scale independent image size:"
    
    ' Image width of always half page width (the margins are not taken into account) and horizontally centered
    Proportion = Printer.ScaleWidth / 2 / Picture1.Picture.Width
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth / 4, Printer.CurrentY + 500, Picture1.Picture.Width * Proportion, Picture1.Picture.Height * Proportion
    
    ' Page 4
    Printer.NewPage
    ' All page os fixed size, regardless of the sacle the user has set
    ' Notes:
    ' This technique can be used for full pages, because it changes Printer.Zoom, and it can be changed after the pages is created
    ' Printer.Zoom needs to be restored in the next page
    
    Printer.Zoom = 100 / PrintPreview1.ScalePercent * 100
    Printer.Print "All page the same size, no matter scale"
    Printer.PaintPicture Picture1.Picture, 0, 500
    Printer.CurrentY = 2700
    Printer.Print "Boat in the middle of the sea"
    
    ' Page 5
    ' Drawing
    Printer.NewPage
    Printer.Zoom = 100
    
    Str = "Drawing" ' title
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.FontUnderline = True
    Printer.Print Str & vbCrLf
    Printer.FontUnderline = False
    
    ' Circle centered horizontally
    Printer.DrawWidth = 10
    Printer.Circle (Printer.ScaleWidth / 2, 2000), 1500, vbRed
    
    ' Rectangle at left
    Printer.Line (0, 4000)-(3000, 6000), vbBlue, B
    
    ' Filled rectangle at right
    Printer.Line (Printer.ScaleWidth - 3000, 4000)-(Printer.ScaleWidth, 6000), vbGreen, BF
    
    ' Triangle drawn with lines, horizontally centered at bottom
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
End Sub

