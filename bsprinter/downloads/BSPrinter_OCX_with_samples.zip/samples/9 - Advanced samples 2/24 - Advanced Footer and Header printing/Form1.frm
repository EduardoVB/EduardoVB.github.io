VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Advanced Header sample"
   ClientHeight    =   4776
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   5160
   LinkTopic       =   "Form1"
   ScaleHeight     =   4776
   ScaleWidth      =   5160
   Begin VB.PictureBox Picture2 
      Height          =   564
      Left            =   2712
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   516
      ScaleWidth      =   2100
      TabIndex        =   3
      Top             =   120
      Visible         =   0   'False
      Width           =   2148
   End
   Begin VB.PictureBox Picture1 
      Height          =   540
      Left            =   4440
      Picture         =   "Form1.frx":97F6
      ScaleHeight     =   492
      ScaleWidth      =   420
      TabIndex        =   2
      Top             =   4080
      Visible         =   0   'False
      Width           =   468
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview window"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   612
      Left            =   864
      TabIndex        =   0
      Top             =   768
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3264
      Top             =   744
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label3 
      Caption         =   "Note: for printing text with better options for positioning, you can use PrintPreview1.PrintEx instead of Printer.Print."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   540
      Left            =   288
      TabIndex        =   5
      Top             =   3648
      Width           =   4596
   End
   Begin VB.Label Label2 
      Caption         =   "The same can be done on the bottom nmargin for printing a footer."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   540
      Left            =   288
      TabIndex        =   4
      Top             =   3024
      Width           =   4596
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":21EE8
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   972
      Left            =   288
      TabIndex        =   1
      Top             =   1968
      Width           =   4596
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    ' the following line is a setting for not allowing the user to place the page numbers at the top
    PrintPreview1.PageNumbersPositionFlags = bsPFAllAvailable And (Not bsPFAllTopAvailable)
    
    ' we will reserve some space at the top, so there is always enough margin for our header
    PrintPreview1.MinTopMargin = 25 ' 25 mm
    
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

Private Sub PrintPreview1_StartPage()
    Dim X As Single
    Dim ImgWidth As Single
    Dim ImgHeight As Single
    Dim ImgScale As Single
    Dim ImageFixedHeight As Single
    
    ' we'll use this event to do the printing of the custom header
    PrintPreview1.HandleMargins = False ' we want to see the whole page with the properties ScaleWidth, CurrentX, CurrentY, etc. So we switched margins handling off momentarily
    
    ImgWidth = Printer.ScaleX(Picture2.Picture.Width, vbHimetric, Printer.ScaleMode)
    ImgHeight = Printer.ScaleY(Picture2.Picture.Height, vbHimetric, Printer.ScaleMode)
    
    ImageFixedHeight = 1000 / PrintPreview1.ScalePercent * 100 ' we are working with the Printer in twips, 1000 are 1000 twips
    ImgScale = ImageFixedHeight / ImgHeight
    
    ' We will paint the image several times at the top of the page
    X = 0
    Do
        Printer.PaintPicture Picture2.Picture, X, 0, ImgWidth * ImgScale, ImgHeight * ImgScale
        X = X + (ImgWidth + Printer.ScaleX(2, vbMillimeters, Printer.ScaleMode)) * ImgScale ' added 2 millimeters space between contiguos images
        If X > Printer.ScaleWidth Then Exit Do
    Loop
    PrintPreview1.HandleMargins = True ' turn margins handling on again before leaving
End Sub

' code taken from Sample 2, just to print something
Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim Str As String
    
    ' Text positioning
    
    Printer.FontSize = 18
    Printer.FontBold = True
    
    'The following code centers the title
    Str = "CENTERED TITLE"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.Print Str
    Printer.Print vbCrLf ' line feed to have some space with the next printing
    
    Printer.FontSize = 12
    Printer.FontBold = False
    
    ' Text positioned at left
    Printer.Print "Left positioned";
    
    ' Text positioned at right
    Str = "Right positioned"
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text positioned at bottom left
    Str = "Bottom left"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.Print Str
    
    ' Text positioned at bottom right
    Str = "Bottom right"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text at center of page
    Str = "Page centered"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.CurrentY = (Printer.ScaleHeight - Printer.TextHeight(Str)) / 2
    Printer.Print Str
    
    
    ' Page 2
    ' Image positioning
    Printer.NewPage
    
    ' Left top
    Printer.PaintPicture Picture1.Picture, 0, 0
    
    ' Right top
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), 0

    ' Left Bottom
    Printer.PaintPicture Picture1.Picture, 0, Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Right Bottom
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Centered in page
    Printer.PaintPicture Picture1.Picture, (Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode)) / 2, (Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)) / 2

    
    ' Page 3
    ' Some elements of always the same size, no matter the scale the user sets
    Printer.NewPage
    Printer.Print "Some elements keep their size"
    Printer.Print "(regardless of scale)"

    Printer.FontSize = 24 * 100 / PrintPreview1.ScalePercent
    
    Printer.Print
    Printer.Print
    Printer.Print ; "Scale independent text size"
    
    Printer.FontSize = 12 ' restore the font size to old value of 12
    Printer.Print "Variable size text"
    
    ' Fixed size image
    Dim Proportion As Single
    
    Printer.Print
    Printer.Print
    Printer.Print "Scale independent image size:"
    
    ' Image width of always half page width (the margins are not taken into account) and horizontally centered
    Proportion = Printer.ScaleWidth / 2 / Picture1.Picture.Width
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth / 4, Printer.CurrentY + 500, Picture1.Picture.Width * Proportion, Picture1.Picture.Height * Proportion
    
    ' Page 4
    Printer.NewPage
    ' All page os fixed size, regardless of the sacle the user has set
    ' Notes:
    ' This technique can be used for full pages, because it changes Printer.Zoom, and it can be changed after the pages is created
    ' Printer.Zoom needs to be restored in the next page
    
    Printer.Zoom = 100 / PrintPreview1.ScalePercent * 100
    Printer.Print "All page the same size, no matter scale"
    Printer.PaintPicture Picture1.Picture, 0, 500
    Printer.CurrentY = 2700
    Printer.Print "Boat in the middle of the sea"
    
    ' Page 5
    ' Drawing
    Printer.NewPage
    Printer.Zoom = 100
    
    Str = "Drawing" ' title
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.FontUnderline = True
    Printer.Print Str & vbCrLf
    Printer.FontUnderline = False
    
    ' Circle centered horizontally
    Printer.DrawWidth = 10
    Printer.Circle (Printer.ScaleWidth / 2, 2000), 1500, vbRed
    
    ' Rectangle at left
    Printer.Line (0, 4000)-(3000, 6000), vbBlue, B
    
    ' Filled rectangle at right
    Printer.Line (Printer.ScaleWidth - 3000, 4000)-(Printer.ScaleWidth, 6000), vbGreen, BF
    
    ' Triangle drawn with lines, horizontally centered at bottom
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
End Sub

