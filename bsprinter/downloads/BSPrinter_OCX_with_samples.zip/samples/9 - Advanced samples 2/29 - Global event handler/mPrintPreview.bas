Attribute VB_Name = "mPrintPreview"
Option Explicit

Public gReportLogger As cLogReports

'Needed for print preview:
Public Property Get Printer() As Printer
    Set Printer = PrinterReplacement
End Property

Public Property Set Printer(nPrinter As Printer)
    Set PrinterReplacement = nPrinter
End Property

