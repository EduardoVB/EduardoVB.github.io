VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Global event handler"
   ClientHeight    =   4224
   ClientLeft      =   780
   ClientTop       =   1956
   ClientWidth     =   5088
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   4224
   ScaleWidth      =   5088
   Begin VB.CommandButton Command2 
      Caption         =   "Show Form3"
      Height          =   612
      Left            =   800
      TabIndex        =   2
      Top             =   1176
      Width           =   1572
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show Form2"
      Height          =   612
      Left            =   800
      TabIndex        =   0
      Top             =   408
      Width           =   1572
   End
   Begin VB.Label Label2 
      Caption         =   "We use the ReportName property for the report identification."
      Height          =   756
      Left            =   312
      TabIndex        =   3
      Top             =   3072
      Width           =   4632
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":0000
      Height          =   756
      Left            =   312
      TabIndex        =   1
      Top             =   2232
      Width           =   4632
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    Form2.Show
End Sub

Private Sub Command2_Click()
    Form3.Show
End Sub

Private Sub Form_Load()
    ' make a new instance of the class cLogReports that is hold by a variable in the bas module
    Set gReportLogger = New cLogReports
End Sub
