VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Full backward compatibility"
   ClientHeight    =   6048
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   5160
   LinkTopic       =   "Form1"
   ScaleHeight     =   6048
   ScaleWidth      =   5160
   Begin VB.PictureBox Picture1 
      Height          =   492
      Left            =   4560
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   444
      ScaleWidth      =   444
      TabIndex        =   2
      Top             =   1344
      Visible         =   0   'False
      Width           =   492
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview window"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   612
      Left            =   864
      TabIndex        =   0
      Top             =   768
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3264
      Top             =   744
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label7 
      Caption         =   $"Form1.frx":18652
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   996
      Left            =   312
      TabIndex        =   8
      Top             =   4872
      Width           =   4572
   End
   Begin VB.Label Label6 
      Caption         =   "You can set them in code or at design time."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   312
      TabIndex        =   7
      Top             =   4392
      Width           =   4572
   End
   Begin VB.Label Label5 
      Caption         =   "AllowUserChangePageNumbers"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   312
      TabIndex        =   6
      Top             =   3888
      Width           =   4572
   End
   Begin VB.Label Label4 
      Caption         =   "PrintPageNumbers"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   312
      TabIndex        =   5
      Top             =   3576
      Width           =   4572
   End
   Begin VB.Label Label3 
      Caption         =   "HandleMargins"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   312
      TabIndex        =   4
      Top             =   3288
      Width           =   4572
   End
   Begin VB.Label Label2 
      Caption         =   "You must set these properties to False:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   312
      TabIndex        =   3
      Top             =   2928
      Width           =   4572
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":18700
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   828
      Left            =   312
      TabIndex        =   1
      Top             =   1944
      Width           =   4572
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
    ' the following three properties can be set to False for full compatibility with already existent code
    ' the user will lose the ability to change margins and page numbers options
    PrintPreview1.HandleMargins = False
    PrintPreview1.PrintPageNumbers = False
    PrintPreview1.AllowUserChangePageNumbers = False
End Sub
Private Sub Command1_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

' code taken from Sample 2, just to print something
Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim Str As String
    
    ' Text positioning
    
    Printer.FontSize = 18
    Printer.FontBold = True
    
    'The following code centers the title
    Str = "CENTERED TITLE"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.Print Str
    Printer.Print vbCrLf ' line feed to have some space with the next printing
    
    Printer.FontSize = 12
    Printer.FontBold = False
    
    ' Text positioned at left
    Printer.Print "Left positioned";
    
    ' Text positioned at right
    Str = "Right positioned"
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text positioned at bottom left
    Str = "Bottom left"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.Print Str
    
    ' Text positioned at bottom right
    Str = "Bottom right"
    Printer.CurrentY = Printer.ScaleHeight - Printer.TextHeight(Str)
    Printer.CurrentX = Printer.ScaleWidth - Printer.TextWidth(Str)
    Printer.Print Str
    
    ' Text at center of page
    Str = "Page centered"
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.CurrentY = (Printer.ScaleHeight - Printer.TextHeight(Str)) / 2
    Printer.Print Str
    
    
    ' Page 2
    ' Image positioning
    Printer.NewPage
    
    ' Left top
    Printer.PaintPicture Picture1.Picture, 0, 0
    
    ' Right top
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), 0

    ' Left Bottom
    Printer.PaintPicture Picture1.Picture, 0, Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Right Bottom
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode), Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)

    ' Centered in page
    Printer.PaintPicture Picture1.Picture, (Printer.ScaleWidth - Picture1.ScaleX(Picture1.Picture.Width, vbHimetric, Printer.ScaleMode)) / 2, (Printer.ScaleHeight - Picture1.ScaleY(Picture1.Picture.Height, vbHimetric, Printer.ScaleMode)) / 2

    
    ' Page 3
    ' Some elements of always the same size, no matter the scale the user sets
    Printer.NewPage
    Printer.Print "Some elements keep their size"
    Printer.Print "(regardless of scale)"

    Printer.FontSize = 24 * 100 / PrintPreview1.ScalePercent
    
    Printer.Print
    Printer.Print
    Printer.Print ; "Scale independent text size"
    
    Printer.FontSize = 12 ' restore the font size to old value of 12
    Printer.Print "Variable size text"
    
    ' Fixed size image
    Dim Proportion As Single
    
    Printer.Print
    Printer.Print
    Printer.Print "Scale independent image size:"
    
    ' Image width of always half page width (the margins are not taken into account) and horizontally centered
    Proportion = Printer.ScaleWidth / 2 / Picture1.Picture.Width
    Printer.PaintPicture Picture1.Picture, Printer.ScaleWidth / 4, Printer.CurrentY + 500, Picture1.Picture.Width * Proportion, Picture1.Picture.Height * Proportion
    
    ' Page 4
    Printer.NewPage
    ' All page os fixed size, regardless of the sacle the user has set
    ' Notes:
    ' This technique can be used for full pages, because it changes Printer.Zoom, and it can be changed after the pages is created
    ' Printer.Zoom needs to be restored in the next page
    
    Printer.Zoom = 100 / PrintPreview1.ScalePercent * 100
    Printer.Print "All page the same size, no matter scale"
    Printer.PaintPicture Picture1.Picture, 0, 500
    Printer.CurrentY = 2700
    Printer.Print "Boat in the middle of the sea"
    
    ' Page 5
    ' Drawing
    Printer.NewPage
    Printer.Zoom = 100
    
    Str = "Drawing" ' title
    Printer.CurrentX = (Printer.ScaleWidth - Printer.TextWidth(Str)) / 2
    Printer.FontUnderline = True
    Printer.Print Str & vbCrLf
    Printer.FontUnderline = False
    
    ' Circle centered horizontally
    Printer.DrawWidth = 10
    Printer.Circle (Printer.ScaleWidth / 2, 2000), 1500, vbRed
    
    ' Rectangle at left
    Printer.Line (0, 4000)-(3000, 6000), vbBlue, B
    
    ' Filled rectangle at right
    Printer.Line (Printer.ScaleWidth - 3000, 4000)-(Printer.ScaleWidth, 6000), vbGreen, BF
    
    ' Triangle drawn with lines, horizontally centered at bottom
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2, Printer.ScaleHeight)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
    Printer.Line (Printer.ScaleWidth / 2 - 1000, Printer.ScaleHeight - 1732)-(Printer.ScaleWidth / 2 + 1000, Printer.ScaleHeight - 1732), vbRed
End Sub


