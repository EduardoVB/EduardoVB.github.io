VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   4716
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   5160
   LinkTopic       =   "Form1"
   ScaleHeight     =   4716
   ScaleWidth      =   5160
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview window"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   612
      Left            =   864
      TabIndex        =   0
      Top             =   768
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3264
      Top             =   744
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":0000
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1140
      Left            =   312
      TabIndex        =   1
      Top             =   2472
      Width           =   4596
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    ' show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    ' the printing code must be here or called from here
    Printer.FontSize = 24
    Printer.Print "Hello World!"
End Sub

