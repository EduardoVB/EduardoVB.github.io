VERSION 5.00
Object = "{451B73A5-1563-45D5-A6AC-7B2B7D30B778}#1.0#0"; "BSPrin10.ocx"
Begin VB.Form Form1 
   Caption         =   "Set default PageView"
   ClientHeight    =   4044
   ClientLeft      =   2652
   ClientTop       =   2160
   ClientWidth     =   5160
   LinkTopic       =   "Form1"
   ScaleHeight     =   4044
   ScaleWidth      =   5160
   Begin VB.CommandButton Command1 
      Caption         =   "Show print preview window"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   612
      Left            =   864
      TabIndex        =   0
      Top             =   768
      Width           =   1572
   End
   Begin BSPrinter.PrintPreview PrintPreview1 
      Left            =   3264
      Top             =   744
      _ExtentX        =   953
      _ExtentY        =   953
   End
   Begin VB.Label Label2 
      Caption         =   "If you set the view to more page than the number of page of the document, they will be handled appropriately anyway."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   972
      Left            =   288
      TabIndex        =   2
      Top             =   2520
      Width           =   4628
   End
   Begin VB.Label Label1 
      Caption         =   "The property 'PageView' sets the default number of pages displayed."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   588
      Left            =   288
      TabIndex        =   1
      Top             =   1848
      Width           =   4628
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
    ' The property 'PageView' sets the default number of pages displayed.
    ' This property can also be set a design time.
    ' If you set the view to more page than the number of page of the document, they will be handled appropriately anyway.
    PrintPreview1.PageView = bsPVTwelvePages
End Sub

Private Sub Command1_Click()
    ' Show the Print Preview dialog
    PrintPreview1.ShowPreview
End Sub

Private Sub PrintPreview1_PrepareReport(Cancel As Boolean)
    Dim c As Long
    
    ' This code simply adds some pages
    Printer.FontSize = 18
    Printer.Print "This is page 1"
    For c = 2 To 30
        Printer.NewPage
        Printer.Print "This is page " & c
    Next c
End Sub

