VERSION 5.00
Object = "{C5743C1F-5CAB-11D6-82C2-000021B74250}#404.0#0"; "vbskpro.ocx"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3915
   ClientLeft      =   1245
   ClientTop       =   1095
   ClientWidth     =   6585
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   3915
   ScaleWidth      =   6585
   Begin VB.PictureBox Picture1 
      Align           =   1  'Align Top
      Height          =   495
      Left            =   0
      ScaleHeight     =   435
      ScaleWidth      =   6525
      TabIndex        =   0
      Top             =   0
      Width           =   6585
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   720
      Top             =   840
      _ExtentX        =   1270
      _ExtentY        =   1270
      ShowSysCommands =   0
      ChangeSkinButton=   0   'False
      LcK1            =   "22-(401(1,-(4444,"
      AmbientB        =   $"Form1.frx":0000
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

