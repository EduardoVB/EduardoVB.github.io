VERSION 5.00
Object = "{C5743C1F-5CAB-11D6-82C2-000021B74250}#409.0#0"; "VBSKPRO.OCX"
Begin VB.Form Form3 
   Caption         =   "Form3"
   ClientHeight    =   3915
   ClientLeft      =   1140
   ClientTop       =   1590
   ClientWidth     =   6585
   LinkTopic       =   "Form3"
   MDIChild        =   -1  'True
   ScaleHeight     =   3915
   ScaleWidth      =   6585
   Begin VB.ComboBox Combo1 
      Height          =   315
      Left            =   300
      TabIndex        =   2
      Text            =   "Combo1"
      Top             =   120
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   495
      Left            =   3210
      TabIndex        =   1
      Top             =   2160
      Width           =   1245
   End
   Begin VB.TextBox Text1 
      Height          =   675
      Left            =   2340
      TabIndex        =   0
      Text            =   "Text1"
      Top             =   240
      Width           =   1755
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   480
      Top             =   420
      _ExtentX        =   1270
      _ExtentY        =   1270
      ShowSysCommands =   0
      ChangeSkinButton=   0   'False
      LcK1            =   "22-(401(1,-(4444,"
      AmbientB        =   $"Form3.frx":0000
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

