VERSION 5.00
Object = "{C5743C1F-5CAB-11D6-82C2-000021B74250}#404.0#0"; "vbskpro.ocx"
Begin VB.Form Form2 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Form2"
   ClientHeight    =   1965
   ClientLeft      =   1305
   ClientTop       =   1125
   ClientWidth     =   4155
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   1965
   ScaleWidth      =   4155
   Begin VB.CommandButton Command1 
      Caption         =   "Close"
      Height          =   495
      Left            =   2700
      TabIndex        =   0
      Top             =   1260
      Width           =   1245
   End
   Begin vbskpro.Skinner Skinner1 
      Left            =   930
      Top             =   180
      _ExtentX        =   1270
      _ExtentY        =   1270
      ShowSysCommands =   0
      ChangeSkinButton=   0   'False
      LcK1            =   "22-(401(1,-(4444,"
      AmbientB        =   $"Form2.frx":0000
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    Unload Me
End Sub
