VERSION 5.00
Begin VB.MDIForm MDIForm1 
   Appearance      =   0  'Flat
   BackColor       =   &H8000000C&
   Caption         =   "MDIForm1"
   ClientHeight    =   3195
   ClientLeft      =   840
   ClientTop       =   1365
   ClientWidth     =   4680
   LinkTopic       =   "MDIForm1"
   WindowState     =   2  'Maximized
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuClose 
         Caption         =   "&Close App"
      End
   End
   Begin VB.Menu mnuForms 
      Caption         =   "Forms"
      Begin VB.Menu mnuForm1 
         Caption         =   "Form1"
      End
      Begin VB.Menu mnuForm2 
         Caption         =   "Form2"
      End
      Begin VB.Menu mnuForm3 
         Caption         =   "Form3"
      End
   End
End
Attribute VB_Name = "MDIForm1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub MDIForm_Load()
    Set frmParent.Form = Me
    frmParent.Show
End Sub

Private Sub mnuClose_Click()
  Unload Me
End Sub

Private Sub mnuForm1_Click()
    Form1.Show
End Sub

Private Sub mnuForm2_Click()
    Form2.Show
End Sub

Private Sub mnuForm3_Click()
    Form3.Show
End Sub
